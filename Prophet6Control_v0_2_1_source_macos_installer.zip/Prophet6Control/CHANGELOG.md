# Changelog

## 0.2.0

* Reframed the project around automation and patch recall. The Prophet onboard step sequencer editor is excluded.
* Separated program sound parameter recall from global configuration recall. Send Globals no longer also sends the program patch.
* Reduced recall pacing to two parameters per processing block as a conservative starting point for USB MIDI traffic.
* Added a named `.p6preset` snapshot workflow and documentation of native SysEx limitations.
* Added Logic routing, preset recall, protocol reference, and known limitation documents.
* Added build and protocol test helper scripts.
* Added test report and Release build assertion compatibility.

## 0.1.0

* Initial JUCE MIDI processor scaffold and Prophet 6 parameter map.

## 0.2.1

* Changed project, `.p6preset`, and `.syx` recall to stage state locally and ask before sending to the Prophet 6.
* Added Recall Hardware and Not Now controls to the editor.
* Added macOS DMG packaging script with AU, VST3, and Standalone bundle installation.
* Added an optional macOS bootstrap script for JUCE 9.0.5, and updated build instructions and preset recall documentation.
* The macOS installer has not yet been generated or validated because this development host is Linux.
