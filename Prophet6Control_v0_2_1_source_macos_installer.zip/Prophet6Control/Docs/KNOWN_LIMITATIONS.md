# Known limitations and release gate

This archive is a development source drop. It is not a production release.

## Not yet validated

* The JUCE plug in targets have not been compiled in this environment because this build host is Linux and no local JUCE source checkout was available. Audio Unit and DMG packaging require macOS tooling.
* The AU has not been loaded in Logic Pro.
* The VST3 target has not been loaded in another host.
* The plug in has not been connected to a physical Prophet 6 Desktop.
* The DMG packaging script has been authored but has not been run on macOS. The package is not code signed or notarised.
* The source currently targets JUCE 9.0.5 as the recommended build dependency. Compilation against this release is not yet verified in this environment.
* MIDI FX input routing for physical control capture has not been confirmed in the user's Logic version.
* Native program dump to edit buffer dump conversion has not been tested on the instrument.
* The exact Prophet 6 installed OS version has not been confirmed.

## Functional limitations

* Automation values are currently polled once per processing block and sent at offset zero. This is not sample accurate.
* Full native SysEx payloads are preserved, but the parser does not yet translate every SysEx patch byte into the displayed parameter values.
* The `.syx` loader imports only the first Prophet 6 message in a file. Bulk bank import and export are not supported.
* There is no native bank browser, patch comparison view, librarian database, or program slot write operation.
* The current user interface is grouped by panel section but is not a pixel accurate Prophet 6 panel recreation.
* The current MIDI FX design expects incoming hardware MIDI to be routed into the processor by the host. The plug in does not independently open a Core MIDI input port.
* Automation and recorded NRPN events can compete if they control the same parameter simultaneously. There is no source priority selector yet.
* MIDI clock is routed by Logic directly to the Prophet. The plug in does not create or regenerate MIDI clock.
* Recall pacing is currently two parameter updates per processing block. The exact sustainable rate must be measured on the physical Prophet 6 at the target Logic buffer sizes.
* NRPN sends do not provide per parameter hardware acknowledgement. Status text reports sent rather than confirmed.
* Global settings are separate from program sound recall. The MIDI Parameter Receive global setting is read only and is not transmitted.

## Production engineering still required

* Build and validate AU and VST3 on Apple Silicon with the current JUCE release.
* Audit all real time code paths and remove any non real time operations from the audio thread.
* Replace block level parameter polling with timestamped host automation event scheduling.
* Implement robust MIDI input and output port policy, including loop detection and reconnection.
* Decode native Prophet 6 SysEx parameter bytes into the parameter model using captured real hardware dumps.
* Add patch readback comparison where supported.
* Verify program dump conversion and edit buffer recall on hardware.
* Validate all control ranges, enumerations, global settings, and parameter scaling against the installed OS.
* Replace the grouped tab UI with a faithfully proportioned panel layout and correctly model continuous, stepped, toggle, and momentary controls.
