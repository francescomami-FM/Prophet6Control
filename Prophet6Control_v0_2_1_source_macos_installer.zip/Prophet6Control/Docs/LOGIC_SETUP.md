# Logic Pro setup and validation

This guide describes the intended signal path. The exact route for recording Prophet front panel movements into a Logic MIDI region depends on the Logic version and the configured MIDI input path. That specific route needs a hardware bench test.

## 1. Prophet 6 global setup

On the Prophet 6, configure the MIDI parameters for NRPN based communication. The exact menu labels should be checked against the manual revision and installed OS on the unit.

Recommended starting configuration:

* Parameter Transmit: NRPN.
* Parameter Receive: NRPN.
* MIDI Control: On.
* MIDI SysEx: On.
* MIDI channel: match the plug in MIDI OUT channel.
* Clock source: external MIDI clock when Logic is the clock master.
* Clock port: USB when the Prophet is connected to the Mac over USB.

Do not assume the software can change every global setting remotely. The Prophet documentation identifies a read only MIDI parameter receive setting, which is deliberately not sent by this project.

## 2. Connect the MIDI and audio paths

1. Connect the Prophet 6 USB port to the Mac.
2. Confirm that macOS Audio MIDI Setup lists the Prophet 6 MIDI device.
3. Create a Logic instrument track.
4. Insert Prophet 6 Control in the MIDI FX slot.
5. Route the MIDI FX output to an External Instrument or a MIDI destination configured for the Prophet 6 USB port.
6. Set the External Instrument audio inputs to the Apogee Symphony inputs receiving the Prophet's analogue outputs.
7. Monitor the audio path independently from the MIDI path.

The software does not use USB audio. The audio remains analogue from the Prophet to the audio interface.

## 3. Automate the Prophet from Logic

1. Open the Prophet 6 Control editor.
2. Confirm the MIDI OUT channel matches the Prophet's receive channel.
3. In Logic, expose the plug in automation parameters for the track.
4. Select a parameter such as Low Pass Cutoff.
5. Draw automation or record automation in Logic.
6. Play the project and confirm that the Prophet changes the corresponding parameter.

The plug in currently emits changed values at the start of its process block. It is not yet sample accurate. Confirm behaviour at the project's sample rate and buffer size before relying on very fast modulation.

## 4. Record movements from the Prophet panel

The intended result is that a physical knob movement is captured as controller data in a Logic MIDI region. In NRPN mode, the event stream is normally made up of CC 99, CC 98, CC 6, and CC 38 messages. The MIDI FX processor can decode these events to update its editor state, while leaving the original events in the MIDI stream.

The required routing must provide the Prophet's USB MIDI input to the Logic track input or an intermediate MIDI routing path, while avoiding a loop back to the same port. Logic's MIDI FX slot is not itself a Core MIDI device input selector. The user must configure the track or Logic MIDI Environment routing so the hardware input reaches the MIDI FX processor and is recorded by a MIDI region.

Bench test sequence:

1. Create a dedicated track for receiving the Prophet USB MIDI input.
2. Arm the track and verify that turning a Prophet parameter produces incoming CC messages.
3. Record a short movement of Low Pass Cutoff.
4. Inspect the MIDI region event list and confirm the NRPN messages are present and ordered.
5. Play the region while the Prophet is configured to receive NRPN.
6. Confirm the physical cutoff follows the recorded movement.
7. Verify that note events are also recorded and replayed as expected.

Do not enable MIDI Thru routing back to the Prophet if it creates a loop of the same input events. If Logic cannot record the hardware input and process it through the same MIDI FX chain, use a dedicated MIDI bridge or an Environment route. This routing decision should be made during the first studio test rather than assumed.

## 5. Avoid competing parameter streams

For a given parameter in a given passage, avoid drawing host automation and simultaneously playing recorded NRPN controller data unless you intentionally want the two streams to compete. The hardware responds to the latest received value. The current prototype has no user selectable priority policy.

## 6. MIDI clock from Logic

Configure Logic as the clock master and enable MIDI clock output to the Prophet 6 USB MIDI destination. Set the Prophet clock mode and clock port to receive external USB MIDI clock. The plug in does not generate clock. Verify arpeggiator timing and transport start and stop separately from parameter automation.

## 7. First studio validation checklist

* Prophet 6 appears as a Core MIDI device.
* NRPN parameter transmit and receive are enabled.
* The plug in's MIDI OUT channel matches the instrument.
* Low Pass Cutoff changes from the plug in.
* Physical cutoff movement updates the plug in if its MIDI input is routed into the processor.
* Logic automation changes the Prophet.
* A hardware movement can be recorded as CC events in a MIDI region.
* The MIDI region replays the recorded movement.
* Project reopening restores the plug in parameter snapshot.
* A captured native edit buffer dump can be saved and restored.
* Logic MIDI clock reaches the Prophet over USB.
