# Patch and preset recall

Preset recall is a primary feature of Prophet 6 Control. Three state formats are deliberately kept distinct because they serve different purposes.

## 1. Logic project state

When Logic saves a project, it stores the plug in parameter state. If the plug in has captured a Prophet 6 edit buffer dump, that native SysEx data is also stored in the plug in state.

On project restoration, the plug in restores parameter values and captured native edit buffer data locally. It does not send MIDI to the hardware automatically. The editor displays a confirmation prompt with two actions. If the project is restored while the editor is closed, the pending prompt appears when the editor is next opened.

* **Recall Hardware** sends the native edit buffer dump first, followed by recorded NRPN overrides. If no native dump exists, it sends the mapped program parameter snapshot.
* **Not Now** leaves the current Prophet hardware sound unchanged. The restored project state remains loaded in the plug in. The mapped parameter snapshot can be sent explicitly with Send Parameters, or the project can be reopened to ask again about the stored native patch.

This restores the exact captured native patch bytes where a valid edit buffer dump is present. It does not yet decode the native dump bytes into all GUI controls. The panel may therefore not visually reflect an imported hardware program even when the hardware receives the correct SysEx patch.

## 2. Prophet 6 Control preset file

The `.p6preset` format is a JSON snapshot with a versioned schema. It stores a human readable name, all mapped parameter values, optional captured edit buffer SysEx, and parameter overrides.

Importing a `.p6preset` loads its values into the plug in without sending MIDI. The user must choose Recall Hardware. A preset created using only the plug in controls is then recalled by sending its parameter values as NRPN. A preset containing a native edit buffer dump first sends the original SysEx patch, then sends the recorded NRPN overrides.

The Global parameter domain is stored in the file but is not included in normal sound patch recall. Use Send Globals only when intentionally changing system wide instrument settings.

## 3. Native Prophet 6 SysEx

The current implementation recognises one edit buffer dump or one program dump. Importing a SysEx file stages it locally and asks before sending. On confirmation, the edit buffer dump is transmitted as received. A program dump is converted to an edit buffer dump command and loaded into the current edit buffer. This is intended to avoid writing over a stored program slot, but must be verified on the physical instrument before using valuable patches.

The loader selects the first Prophet 6 SysEx message found in the file. Bulk bank import, bank selection, program browser, and bulk export are not implemented.

## 4. Capturing a native patch

1. Route Prophet 6 USB MIDI input back to the plug in's host MIDI input path.
2. Click Request Hardware Patch.
3. The plug in sends the Prophet edit buffer dump request.
4. When the edit buffer SysEx response reaches the processor, the native bytes are retained.
5. Click Export SysEx to save the captured `.syx` file, or Save Preset to store it inside a `.p6preset` snapshot.

If the response does not reach the plug in, no dump is captured. The status message is not proof of a successful hardware response. Confirm that the exported file is a Prophet 6 edit buffer dump before treating the operation as complete.

## 5. Recall status and acknowledgements

The current recall queue emits two parameter updates per processing block to avoid a large burst of NRPN controller messages. This pacing has not been measured on the physical instrument. NRPN parameter changes do not provide a general acknowledgement for every parameter. The plug in therefore reports that a recall stream has been sent, not that every value has been confirmed by the synthesiser. A confirmation prompt is presented after Logic project restoration, `.p6preset` import, and native `.syx` import. A user can defer sending and confirm later.

For robust recall, the next development stage should add a hardware connection monitor, request and compare edit buffer readback where practical, and provide a clear distinction between queued, sent, read back, and failed states.

## 6. Important current limitation

The native SysEx payload is preserved byte for byte, but a complete byte offset map from the packed native payload to every NRPN controlled parameter has not yet been verified against a real Prophet 6 dump. Complete GUI hydration after loading an external `.syx` is not implemented. This is a required engineering step before advertising full hardware preset librarian or visual Total Recall functionality.
