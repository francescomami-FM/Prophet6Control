# Protocol reference and source notes

## Primary documentation

Sequential official Prophet 6 documentation and downloads:

https://sequential.com/support/downloads/

Prophet 6 Operation Manual, official PDF:

https://sequential.com/wp-content/uploads/2021/02/Prophet-6-Operation-Manual-2.1.pdf

Sequential Prophet 6 OS and support information:

https://sequential.com/support/download/prophet-6-operating-system/

## NRPN transport

The Prophet 6 full parameter map is addressed using NRPN. The NRPN address and data are transported as ordinary MIDI CC messages:

| CC | Meaning |
| ---: | --- |
| 99 | NRPN parameter number MSB |
| 98 | NRPN parameter number LSB |
| 6 | Data Entry MSB |
| 38 | Data Entry LSB |
| 96 | Data Increment |
| 97 | Data Decrement |

The implementation transmits all four address and data messages for each parameter change. NRPN parameter values are represented as a 14 bit number, although individual Prophet parameters have their own narrower documented limits. The parameter definition clamps outgoing and incoming values to the mapped range.

The direct CC table is a subset and is not sufficient for full panel automation. The project uses NRPN for full coverage and recognises direct CC input only where the manual lists a direct assignment.

## SysEx framing implemented

The current code recognises the Sequential manufacturer ID `01` and Prophet 6 device ID `2D`.

* Edit buffer dump request: `F0 01 2D 06 F7`.
* Program dump request: `F0 01 2D 05 bank program F7`.
* Edit buffer dump: command `03`, followed by 1171 packed 7 bit bytes.
* Program dump: command `02`, bank and program fields, followed by 1171 packed 7 bit bytes.

The unpacked program payload is 1024 bytes. Seven bit packing stores the high bits in a flag byte followed by up to seven low seven bit data bytes.

The current parser checks framing and expected message lengths. It does not yet decode the internal parameter byte offsets into the GUI parameter model.

## Parameter table scope

The structured parameter map is transcribed from the NRPN and direct CC tables in the official Prophet 6 manual. Program sound parameters and global configuration parameters are maintained as separate domains. Internal step sequencer note and velocity lanes are excluded by design because sequencing takes place in Logic.

The installed operating system on the target synthesiser must be recorded during the first bench test. If Sequential has changed any parameter definition or behaviour between the manual revision and installed OS, the map must be reconciled before release.

## Source verification status

The manual is the primary authority for message structure and documented parameter mapping. The code's protocol tests validate internal encoding, decoding, parameter map uniqueness, and SysEx byte packing. They do not prove that the physical Prophet 6 responds correctly. Hardware behaviour, scaling, enumerations, and edit buffer loading remain bench tests.
