# Technical specification. Prophet 6 Control 0.2.1

## Product priorities

The implementation order is:

1. Host automation of mapped sound parameters.
2. Save and recall of plug in state and named presets.
3. Native Prophet 6 edit buffer capture and restoration.
4. Bidirectional parameter feedback.
5. A panel layout that follows the physical instrument.

The Prophet 6 internal step sequencer editor is deliberately excluded. Notes are sequenced in Logic. The Prophet arpeggiator controls and program clock parameter remain available because they are sound and performance parameters rather than the internal sequence editor.

## Parameter model

Each parameter definition contains a stable identifier, display name, panel section, NRPN number, minimum, maximum, default, optional direct CC mapping, and a Program or Global domain.

The order of parameter definitions is part of the saved automation contract. Released parameter IDs and their ranges must remain stable. New entries should be appended. Any corrections to the NRPN table must be treated as schema changes and checked against saved projects.

Program parameters control the sound and performance configuration stored with a Prophet patch. Global parameters affect the instrument's system configuration and are recalled separately. Read only parameters are displayed but never transmitted.

## Automation behaviour

The host automation parameter tree is the source of truth during automated playback. Each changed parameter is encoded as a complete NRPN sequence and added to the MIDI output stream.

The implementation currently polls the AudioProcessorValueTreeState values once per process block. Changed values are emitted at sample offset zero. This is block level automation and is not sample accurate. It is adequate for an initial routing and usability prototype, but should be replaced by a timestamped queue for fast modulation, exact event alignment, or dense automation.

Incoming NRPN and supported direct CC events are decoded. The decoded value is applied to the matching host parameter using a message thread notification. The incoming MIDI bytes remain in the MIDI stream so the host can potentially record the original controller sequence.

The processor sends the full NRPN parameter address and value on each change. This makes the message sequence independent of a previously selected NRPN address and is safer when other controller sources share the MIDI path.

When a parameter is being changed by the hardware, the processor marks that value as hardware originated and suppresses an immediate echo of the same value back to the device. The exact Logic routing required to feed hardware input into the MIDI FX processor must be validated in the target Logic version.

## Automation source priority

A parameter can be influenced by the plug in's host automation or by recorded NRPN events in a MIDI region. These are separate streams. For deterministic results, use one source at a time for each parameter during a given passage. If both streams control the same parameter simultaneously, the Prophet receives whichever message arrives last.

A future production version should expose an explicit source priority policy, for example host automation wins, MIDI region wins, or last event wins. The current implementation does not provide that selector.

## Patch and preset model

The software distinguishes three forms of state:

### Logic project state

The Audio Unit state stores host parameter values and, if captured, the native Prophet edit buffer SysEx dump. On project restore, the plug in restores the local state and sets a hardware recall confirmation flag. It does not send a patch automatically. The editor presents Recall Hardware and Not Now. If confirmed, the plug in queues the native edit buffer dump first and then sends parameter overrides. If no native dump is present, it queues the current program parameter snapshot. Not Now leaves the hardware untouched while keeping the loaded state in the plug in.

### Prophet 6 Control preset

A `.p6preset` JSON file stores:

* Format identifier and schema version.
* Display name.
* Current values for all mapped program and global parameters.
* Optional native edit buffer SysEx data encoded as Base64.
* Parameter overrides captured after the native edit buffer was loaded.

Global values are stored in the file, but ordinary Send Parameters recall excludes them. The separate Send Globals command is explicit.

### Native Prophet SysEx

The implementation recognises one Prophet 6 program dump or edit buffer dump. A program dump is reframed as an edit buffer dump so the sound can be loaded into the current edit buffer rather than writing a stored program slot. This conversion has not yet been tested on the physical instrument.

A captured native edit buffer dump is retained byte for byte. Importing a `.p6preset` or `.syx` stages it locally and requests explicit user confirmation before hardware transmission. The current code does not yet decode the packed SysEx payload into every visible panel value. Consequently, native sound restoration and graphical parameter hydration are not yet equivalent. A verified field map is needed for complete visual Total Recall.

The `.syx` loader currently imports the first Prophet 6 SysEx message found in the file. Bulk bank import and export are not implemented.

## Recall queue

Program parameter recall is paced at two parameters per process block to limit bursts of four CC messages per parameter. This is a conservative software pacing rule, not a measured Prophet hardware limit. Writable global recall is a separate operation. Read only global parameters are excluded. The recall status states that data was sent, not acknowledged.

The queue is currently fixed paced by process block. A production implementation should measure the Prophet's receive behaviour and introduce a configurable inter-message interval, retry handling, explicit port monitoring, and a cancel action. It should not claim that the hardware is connected merely because MIDI output events have been generated.

## MIDI clock

Logic is the clock master. The user configures Logic to send MIDI clock and transport to the Prophet USB MIDI destination. The plug in does not generate a second clock. Clock routing should bypass the parameter recall engine unless Logic's MIDI FX routing has been explicitly validated for clock passthrough.

## Audio routing

No USB audio is required. The Prophet analogue outputs connect to the audio interface. Logic's External Instrument or equivalent routing handles audio input and MIDI output.

## Interface

The current editor groups the available controls by Prophet panel section. Continuous parameters use rotary controls, binary parameters use toggles, and small enumerated ranges use selectors. The visual arrangement is functional but not yet a precise recreation of the hardware panel dimensions, knob positions, legends, colours, or switch graphics.

## Protocol sources

The NRPN map and data ranges are transcribed from Sequential's Prophet 6 Operation Manual MIDI implementation appendix. The protocol reference and open items are recorded in [PROTOCOL_REFERENCE.md](PROTOCOL_REFERENCE.md).
