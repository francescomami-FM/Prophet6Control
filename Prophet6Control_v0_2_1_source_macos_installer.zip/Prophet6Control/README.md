# Prophet 6 Control. Development source 0.2.1

Prophet 6 Control is a JUCE based MIDI editor and automation processor for the Sequential Prophet 6 Desktop. The current development priority is full parameter automation, reliable patch recall, and two way parameter feedback. The Prophet's internal step sequencer editor is intentionally out of scope. Note sequencing remains in Logic.

This archive contains C++ source, protocol tests, build scripts, and setup documentation. It is not an installed Audio Unit or VST3 binary.

## Current scope

The project currently includes:

* A JUCE plug in target configured for Audio Unit, VST3, and Standalone builds.
* A structured Prophet 6 parameter map for program sound parameters and separately managed global parameters.
* Host automatable integer parameters for the mapped sound controls.
* NRPN encoding and decoding using CC 99, 98, 6, and 38.
* Input decoding for the Prophet's documented direct CC mappings.
* A parameter feedback path from incoming hardware events to the plug in parameter tree.
* A paced parameter recall queue, limited to two parameters per processing block, for sound parameters and a separate explicit queue for writable global parameters.
* Explicit hardware recall confirmation after Logic project restoration, `.p6preset` import, or native `.syx` import. The patch is loaded into the plug in first, then the user chooses Recall Hardware or Not Now.
* Plug in project state serialisation.
* A named `.p6preset` snapshot format.
* Capture and export of a Prophet 6 edit buffer SysEx dump.
* Import of one Prophet 6 program or edit buffer SysEx message.
* A first grouped control interface, with continuous controls, toggles, and stepped selectors.
* Independent protocol tests for NRPN, parameter map integrity, and SysEx packing and framing.

The current interface is a functional grouped editor. It is not yet a pixel accurate reproduction of the Prophet 6 panel.

## Automation design

Each mapped program parameter is exposed to the host as an Audio Unit parameter. When Logic changes an automated parameter, the processor detects the new integer value and emits a full NRPN address and value sequence to the downstream MIDI path.

Incoming Prophet parameter messages are decoded and used to update the plug in parameter tree. The original incoming MIDI events are retained in the MIDI stream so that the DAW can record and replay the CC messages where its routing permits this.

The current automation sender checks parameter values once per processing block and emits changed values at the beginning of that block. It is therefore a functional first implementation, not sample accurate MIDI automation. A production release should use timestamped parameter events and a bounded event queue.

## Patch and preset recall

There are three different recall layers:

1. Logic project state. Logic saves the plug in parameter values and the captured native edit buffer data, where available.
2. Prophet 6 Control preset. A `.p6preset` file stores the parameter snapshot, optional native edit buffer SysEx data, and parameter overrides made after capture.
3. Native Prophet 6 SysEx. A single program dump or edit buffer dump can be imported. A captured edit buffer dump can be exported as `.syx`.

A native edit buffer dump preserves the Prophet's patch data. Importing a `.syx` file stages the patch locally and asks before sending it. The current code does not decode every internal SysEx byte into the visible parameter controls, so panel values may not reflect an imported native patch until the dump field map has been verified and implemented.

The plug in reports that NRPN recall was sent. NRPN does not provide a general parameter acknowledgement, so the software does not claim that a connected instrument has confirmed every change.

Ordinary sound patch recall excludes global settings. Global settings are separate and have a separate explicit Send Globals action. Read only global parameters are not sent.

## MIDI protocol

The Prophet 6 uses NRPN messages for full parameter access. NRPN is carried as ordinary MIDI CC messages:

| MIDI CC | Meaning |
| ---: | --- |
| 99 | NRPN parameter number MSB |
| 98 | NRPN parameter number LSB |
| 6 | Data Entry MSB |
| 38 | Data Entry LSB |

The processor sends all four messages for each update. This is deliberately conservative when other MIDI sources may interleave controller traffic. Direct CC input is supported only for parameters with a published direct CC mapping. Full parameter coverage uses NRPN.

## Build and create the macOS installer

Requirements:

* macOS with Xcode command line tools.
* CMake 3.22 or newer.
* A JUCE 9.0.5 source checkout. This is the current JUCE release identified in the official release announcements on 6 November 2026. <https://forum.juce.com/t/juce-9-0-5-released-meet-the-juce-team-at-adc/69809>
* Apple Silicon is the default build architecture. Set `CMAKE_OSX_ARCHITECTURES` to `arm64;x86_64` for a Universal build if the dependencies support it.

To download JUCE 9.0.5 and build on macOS:

```bash
./scripts/bootstrap_and_build_macos.sh
```

Or use an existing JUCE checkout:

```bash
./scripts/build_macos.sh /absolute/path/to/JUCE
```

The script builds AU, VST3 and Standalone formats, then creates `dist/Prophet-6-Control-v0.2.1.dmg`. The DMG contains an `Install.command` that copies the AU and VST3 into the current user's Audio Plug-Ins folders, and the Standalone application into `~/Applications` when that target is produced.

The confirmation prompt appears in the plug in editor. If Logic restores the project while the editor is closed, the recall remains pending and the prompt appears when the editor is opened. The DMG created by this development script is not code signed or notarised. A distributable release requires an Apple Developer ID signing identity and notarisation. This package has not yet been built on macOS in the current development environment.

## Run protocol tests

The protocol tests do not require JUCE:

```bash
./scripts/test_protocols.sh
```

## Logic setup

Read [Docs/LOGIC_SETUP.md](Docs/LOGIC_SETUP.md) for the proposed routing, external instrument setup, parameter automation workflow, recording of physical control movements, and MIDI clock configuration.

## Preset workflow

Read [Docs/PRESET_RECALL.md](Docs/PRESET_RECALL.md) for the difference between Logic project state, `.p6preset` files, and native Prophet 6 SysEx data.

## Engineering status

Read [Docs/KNOWN_LIMITATIONS.md](Docs/KNOWN_LIMITATIONS.md) before treating this as production software. The protocol unit tests pass in the development environment. The JUCE plug in has not been compiled in this environment, loaded in Logic, or tested against a physical Prophet 6. AU and VST3 compatibility therefore remain unverified.
