#include "ParameterMap.h"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace p6
{
    // Parameter order is part of the saved AU automation contract.
    // Do not reorder or remove entries after release. Append new entries only.
    const std::vector<ParameterDefinition>& parameterDefinitions()
    {
        static const std::vector<ParameterDefinition> definitions = {
            // OSCILLATOR 1
            {"osc1_frequency", "Frequency", "Oscillator 1", "Panel", 0, 0, 60, 30, 67, ParameterDomain::Program, false, false},
            {"osc1_sync", "Sync", "Oscillator 1", "Panel", 1, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"osc1_level", "Osc 1 Level", "Mixer", "Panel", 2, 0, 127, 100, 69, ParameterDomain::Program, false, false},
            {"osc1_shape", "Shape", "Oscillator 1", "Panel", 3, 0, 254, 127, 70, ParameterDomain::Program, false, false},
            {"osc1_pulse_width", "Pulse Width", "Oscillator 1", "Panel", 4, 0, 255, 127, 71, ParameterDomain::Program, false, false},

            // OSCILLATOR 2
            {"osc2_frequency", "Frequency", "Oscillator 2", "Panel", 5, 0, 60, 30, 75, ParameterDomain::Program, false, false},
            {"osc2_frequency_fine", "Fine", "Oscillator 2", "Panel", 6, 0, 254, 127, 76, ParameterDomain::Program, false, false},
            {"osc2_level", "Osc 2 Level", "Mixer", "Panel", 7, 0, 127, 100, 77, ParameterDomain::Program, false, false},
            {"osc2_shape", "Shape", "Oscillator 2", "Panel", 8, 0, 254, 127, 78, ParameterDomain::Program, false, false},
            {"osc2_pulse_width", "Pulse Width", "Oscillator 2", "Panel", 9, 0, 255, 127, 79, ParameterDomain::Program, false, false},
            {"osc2_low_frequency", "Low Frequency", "Oscillator 2", "Panel", 10, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"osc2_key_tracking", "Keyboard", "Oscillator 2", "Panel", 11, 0, 1, 1, -1, ParameterDomain::Program, true, false},

            // MIXER / GLIDE / PERFORMANCE-RELATED PANEL CONTROLS
            {"sub_oscillator_level", "Sub Osc", "Mixer", "Panel", 27, 0, 127, 0, 8, ParameterDomain::Program, false, false},
            {"noise_level", "Noise", "Mixer", "Panel", 32, 0, 127, 0, -1, ParameterDomain::Program, false, false},
            {"glide_mode", "Glide Mode", "Glide / Unison", "Panel", 28, 0, 3, 0, 5, ParameterDomain::Program, false, false},
            {"glide_enabled", "Glide", "Glide / Unison", "Panel", 29, 0, 1, 0, 65, ParameterDomain::Program, true, false},
            {"glide_rate", "Glide Rate", "Glide / Unison", "Panel", 30, 0, 127, 0, -1, ParameterDomain::Program, false, false},
            {"pitch_bend_range", "Pitch Bend Range", "Glide / Unison", "Panel", 31, 0, 24, 2, -1, ParameterDomain::Program, false, false},
            {"slop", "Slop", "Misc", "Panel", 33, 0, 127, 0, -1, ParameterDomain::Program, false, false},
            {"voice_volume", "Voice Volume", "Misc", "Panel", 62, 0, 127, 100, -1, ParameterDomain::Program, false, false},
            {"pan_spread", "Pan Spread", "Misc", "Panel", 63, 0, 127, 0, -1, ParameterDomain::Program, false, false},
            {"distortion_amount", "Distortion", "Misc", "Panel", 64, 0, 127, 0, 9, ParameterDomain::Program, false, false},
            {"unison_enabled", "Unison", "Glide / Unison", "Panel", 156, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"unison_mode", "Unison Mode", "Glide / Unison", "Panel", 157, 0, 6, 0, -1, ParameterDomain::Program, false, false},
            {"key_mode", "Key Mode", "Glide / Unison", "Panel", 158, 0, 5, 0, -1, ParameterDomain::Program, false, false},

            // LOW-PASS FILTER
            {"lowpass_cutoff", "Cutoff", "Low-pass Filter", "Panel", 45, 0, 164, 120, 102, ParameterDomain::Program, false, false},
            {"lowpass_resonance", "Resonance", "Low-pass Filter", "Panel", 46, 0, 255, 0, 103, ParameterDomain::Program, false, false},
            {"lowpass_keyboard_amount", "Keyboard Amount", "Low-pass Filter", "Panel", 47, 0, 2, 0, 104, ParameterDomain::Program, false, false},
            {"lowpass_velocity", "Velocity", "Low-pass Filter", "Panel", 48, 0, 1, 0, 105, ParameterDomain::Program, true, false},
            {"lowpass_envelope_amount", "Envelope Amount", "Low-pass Filter", "Panel", 77, 0, 254, 127, 47, ParameterDomain::Program, false, false},

            // HIGH-PASS FILTER
            {"highpass_cutoff", "Cutoff", "High-pass Filter", "Panel", 49, 0, 164, 0, 106, ParameterDomain::Program, false, false},
            {"highpass_resonance", "Resonance", "High-pass Filter", "Panel", 50, 0, 255, 0, 107, ParameterDomain::Program, false, false},
            {"highpass_keyboard_amount", "Keyboard Amount", "High-pass Filter", "Panel", 51, 0, 2, 0, 108, ParameterDomain::Program, false, false},
            {"highpass_velocity", "Velocity", "High-pass Filter", "Panel", 52, 0, 1, 0, 109, ParameterDomain::Program, true, false},
            {"highpass_envelope_amount", "Envelope Amount", "High-pass Filter", "Panel", 82, 0, 254, 127, 54, ParameterDomain::Program, false, false},

            // AMPLIFIER ENVELOPE
            {"amp_env_amount", "Amount", "Amplifier Envelope", "Panel", 66, 0, 127, 127, 40, ParameterDomain::Program, false, false},
            {"amp_env_attack", "Attack", "Amplifier Envelope", "Panel", 67, 0, 127, 0, 43, ParameterDomain::Program, false, false},
            {"amp_env_decay", "Decay", "Amplifier Envelope", "Panel", 68, 0, 127, 80, 44, ParameterDomain::Program, false, false},
            {"amp_env_sustain", "Sustain", "Amplifier Envelope", "Panel", 69, 0, 127, 127, 45, ParameterDomain::Program, false, false},
            {"amp_env_release", "Release", "Amplifier Envelope", "Panel", 70, 0, 127, 20, 46, ParameterDomain::Program, false, false},
            {"amp_env_velocity", "Velocity", "Amplifier Envelope", "Panel", 71, 0, 1, 0, 41, ParameterDomain::Program, true, false},

            // FILTER ENVELOPE
            {"filter_env_attack", "Attack", "Filter Envelope", "Panel", 78, 0, 127, 0, 50, ParameterDomain::Program, false, false},
            {"filter_env_decay", "Decay", "Filter Envelope", "Panel", 79, 0, 127, 80, 51, ParameterDomain::Program, false, false},
            {"filter_env_sustain", "Sustain", "Filter Envelope", "Panel", 80, 0, 127, 0, 52, ParameterDomain::Program, false, false},
            {"filter_env_release", "Release", "Filter Envelope", "Panel", 81, 0, 127, 20, 53, ParameterDomain::Program, false, false},

            // LFO
            {"lfo_frequency", "Frequency", "LFO", "Modulation", 88, 0, 254, 0, -1, ParameterDomain::Program, false, false},
            {"lfo_initial_amount", "Initial Amount", "LFO", "Modulation", 89, 0, 255, 0, -1, ParameterDomain::Program, false, false},
            {"lfo_shape", "Shape", "LFO", "Modulation", 90, 0, 4, 0, -1, ParameterDomain::Program, false, false},
            {"lfo_sync", "Sync", "LFO", "Modulation", 91, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"lfo_freq1_destination", "Freq 1", "LFO Destinations", "Modulation", 93, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"lfo_freq2_destination", "Freq 2", "LFO Destinations", "Modulation", 94, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"lfo_pulsewidth_destination", "PW 1 + 2", "LFO Destinations", "Modulation", 95, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"lfo_amp_destination", "Amp", "LFO Destinations", "Modulation", 96, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"lfo_lowpass_destination", "Low-pass", "LFO Destinations", "Modulation", 97, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"lfo_highpass_destination", "High-pass", "LFO Destinations", "Modulation", 98, 0, 1, 0, -1, ParameterDomain::Program, true, false},

            // AFTERTOUCH
            {"pressure_amount", "Amount", "Aftertouch", "Modulation", 109, 0, 254, 0, -1, ParameterDomain::Program, false, false},
            {"pressure_freq1_destination", "Freq 1", "Aftertouch Destinations", "Modulation", 110, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"pressure_freq2_destination", "Freq 2", "Aftertouch Destinations", "Modulation", 111, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"pressure_lowpass_destination", "Low-pass", "Aftertouch Destinations", "Modulation", 112, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"pressure_highpass_destination", "High-pass", "Aftertouch Destinations", "Modulation", 113, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"pressure_vca_destination", "VCA", "Aftertouch Destinations", "Modulation", 114, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"pressure_lfo_destination", "LFO Amount", "Aftertouch Destinations", "Modulation", 115, 0, 1, 0, -1, ParameterDomain::Program, true, false},

            // POLY MOD
            {"polymod_filter_env_amount", "Filter Env Amount", "Poly Mod", "Modulation", 143, 0, 254, 0, -1, ParameterDomain::Program, false, false},
            {"polymod_osc2_amount", "Osc 2 Amount", "Poly Mod", "Modulation", 144, 0, 254, 0, -1, ParameterDomain::Program, false, false},
            {"polymod_freq1_destination", "Freq 1", "Poly Mod Destinations", "Modulation", 145, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"polymod_shape1_destination", "Shape 1", "Poly Mod Destinations", "Modulation", 146, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"polymod_pw1_destination", "PW 1", "Poly Mod Destinations", "Modulation", 147, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"polymod_lowpass_destination", "Low-pass", "Poly Mod Destinations", "Modulation", 148, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"polymod_highpass_destination", "High-pass", "Poly Mod Destinations", "Modulation", 149, 0, 1, 0, -1, ParameterDomain::Program, true, false},

            // EFFECTS (the meaning of Param 1 and Param 2 depends on the selected effect)
            {"effects_enabled", "Effects On", "Effects", "Effects", 135, 0, 1, 1, -1, ParameterDomain::Program, true, false},
            {"fx1_select", "FX 1 Type", "Effects 1", "Effects", 119, 0, 5, 0, -1, ParameterDomain::Program, false, false},
            {"fx1_mix", "FX 1 Mix", "Effects 1", "Effects", 120, 0, 127, 50, -1, ParameterDomain::Program, false, false},
            {"fx1_parameter1", "FX 1 Param 1", "Effects 1", "Effects", 121, 0, 255, 0, -1, ParameterDomain::Program, false, false},
            {"fx1_parameter2", "FX 1 Param 2", "Effects 1", "Effects", 122, 0, 127, 0, -1, ParameterDomain::Program, false, false},
            {"fx1_sync", "FX 1 Sync", "Effects 1", "Effects", 123, 0, 1, 0, -1, ParameterDomain::Program, true, false},
            {"fx2_select", "FX 2 Type", "Effects 2", "Effects", 127, 0, 9, 0, -1, ParameterDomain::Program, false, false},
            {"fx2_mix", "FX 2 Mix", "Effects 2", "Effects", 128, 0, 127, 50, -1, ParameterDomain::Program, false, false},
            {"fx2_parameter1", "FX 2 Param 1", "Effects 2", "Effects", 129, 0, 255, 0, -1, ParameterDomain::Program, false, false},
            {"fx2_parameter2", "FX 2 Param 2", "Effects 2", "Effects", 130, 0, 127, 0, -1, ParameterDomain::Program, false, false},
            {"fx2_sync", "FX 2 Sync", "Effects 2", "Effects", 131, 0, 1, 0, -1, ParameterDomain::Program, true, false},

            // ARPEGGIATOR / CLOCK. Sequencer note programming is intentionally handled in Logic.
            {"arp_enabled", "Arp On", "Arpeggiator", "Effects", 160, 0, 1, 0, 58, ParameterDomain::Program, true, false},
            {"arp_mode", "Arp Mode", "Arpeggiator", "Effects", 161, 0, 4, 0, 59, ParameterDomain::Program, false, false},
            {"arp_range", "Arp Range", "Arpeggiator", "Effects", 162, 0, 2, 0, 60, ParameterDomain::Program, false, false},
            {"arp_time_signature", "Arp Time Signature", "Arpeggiator", "Effects", 163, 0, 9, 0, 62, ParameterDomain::Program, false, false},
            {"clock_bpm", "BPM", "Clock", "Effects", 167, 30, 250, 120, 3, ParameterDomain::Program, false, false},

            // GLOBALS. The Prophet-6 stores these separately from the program sound.
            {"global_fine_tune", "Master Fine Tune", "Tuning", "Globals", 1024, 0, 100, 50, -1, ParameterDomain::Global, false, false},
            {"global_coarse_tune", "Master Coarse Tune", "Tuning", "Globals", 1025, 0, 24, 12, -1, ParameterDomain::Global, false, false},
            {"global_midi_channel", "MIDI Channel", "MIDI & Clock", "Globals", 1026, 0, 16, 1, -1, ParameterDomain::Global, false, false},
            {"global_clock_mode", "MIDI Clock Mode", "MIDI & Clock", "Globals", 1027, 0, 3, 2, -1, ParameterDomain::Global, false, false},
            {"global_clock_port", "Clock Port", "MIDI & Clock", "Globals", 1028, 0, 1, 1, -1, ParameterDomain::Global, false, false},
            {"global_param_send", "Parameter Send", "MIDI & Clock", "Globals", 1029, 0, 2, 0, -1, ParameterDomain::Global, false, false},
            {"global_param_receive", "Parameter Receive", "MIDI & Clock", "Globals", 1030, 0, 2, 0, -1, ParameterDomain::Global, false, true},
            {"global_midi_control", "MIDI Control", "MIDI & Clock", "Globals", 1031, 0, 1, 1, -1, ParameterDomain::Global, true, false},
            {"global_sysex_control", "MIDI SysEx", "MIDI & Clock", "Globals", 1032, 0, 1, 1, -1, ParameterDomain::Global, true, false},
            {"global_midi_out", "MIDI Out Select", "MIDI & Clock", "Globals", 1033, 0, 3, 2, -1, ParameterDomain::Global, false, false},
            {"global_local_control", "Local Control", "System", "Globals", 1035, 0, 1, 1, -1, ParameterDomain::Global, true, false},
            {"global_pot_mode", "Pot Mode", "System", "Globals", 1037, 0, 2, 1, -1, ParameterDomain::Global, false, false},
            {"global_seq_jack", "Sequencer Jack", "System", "Globals", 1039, 0, 3, 0, -1, ParameterDomain::Global, false, false},
            {"global_sustain_polarity", "Sustain Polarity", "System", "Globals", 1040, 0, 3, 0, -1, ParameterDomain::Global, false, false},
            {"global_velocity_response", "Velocity Response", "System", "Globals", 1041, 0, 3, 1, -1, ParameterDomain::Global, false, false},
            {"global_aftertouch_response", "Aftertouch Response", "System", "Globals", 1042, 0, 3, 1, -1, ParameterDomain::Global, false, false},
            {"global_stereo_mono", "Stereo / Mono", "System", "Globals", 1043, 0, 1, 0, -1, ParameterDomain::Global, false, false},
            {"global_alt_tuning", "Alternative Tuning", "System", "Globals", 1044, 0, 16, 0, -1, ParameterDomain::Global, false, false}
        };
        return definitions;
    }

    const ParameterDefinition* findParameterByNrpn(int nrpn)
    {
        const auto& defs = parameterDefinitions();
        const auto it = std::find_if(defs.begin(), defs.end(), [nrpn](const auto& d) { return d.nrpn == nrpn; });
        return it == defs.end() ? nullptr : &(*it);
    }

    const ParameterDefinition* findParameterByCC(int cc)
    {
        const auto& defs = parameterDefinitions();
        const auto it = std::find_if(defs.begin(), defs.end(), [cc](const auto& d) { return d.directCC == cc; });
        return it == defs.end() ? nullptr : &(*it);
    }

    int parameterIndex(const char* id)
    {
        const auto& defs = parameterDefinitions();
        for (size_t i = 0; i < defs.size(); ++i)
            if (std::strcmp(defs[i].id, id) == 0)
                return static_cast<int>(i);
        return -1;
    }

    int clampParameterValue(const ParameterDefinition& definition, int value)
    {
        return std::clamp(value, definition.minimum, definition.maximum);
    }

    int ccToParameterValue(const ParameterDefinition& definition, int ccValue)
    {
        const auto bounded = std::clamp(ccValue, 0, 127);
        const auto span = definition.maximum - definition.minimum;
        return definition.minimum + static_cast<int>(std::lround((static_cast<double>(bounded) / 127.0) * span));
    }

    int parameterValueToCC(const ParameterDefinition& definition, int value)
    {
        const auto bounded = clampParameterValue(definition, value);
        const auto span = definition.maximum - definition.minimum;
        if (span <= 0)
            return 0;
        return static_cast<int>(std::lround((static_cast<double>(bounded - definition.minimum) / static_cast<double>(span)) * 127.0));
    }
}
