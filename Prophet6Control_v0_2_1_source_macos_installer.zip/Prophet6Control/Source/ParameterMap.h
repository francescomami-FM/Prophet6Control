#pragma once

#include <string>
#include <vector>

namespace p6
{
    enum class ParameterDomain
    {
        Program,
        Global
    };

    struct ParameterDefinition
    {
        const char* id;
        const char* name;
        const char* section;
        const char* page;
        int nrpn;
        int minimum;
        int maximum;
        int defaultValue;
        int directCC;       // -1 means NRPN only
        ParameterDomain domain;
        bool toggle;
        bool readOnly;      // Host can display the value, but should not send it
    };

    const std::vector<ParameterDefinition>& parameterDefinitions();
    const ParameterDefinition* findParameterByNrpn(int nrpn);
    const ParameterDefinition* findParameterByCC(int cc);
    int parameterIndex(const char* id);
    int clampParameterValue(const ParameterDefinition& definition, int value);
    int ccToParameterValue(const ParameterDefinition& definition, int ccValue);
    int parameterValueToCC(const ParameterDefinition& definition, int value);
}
