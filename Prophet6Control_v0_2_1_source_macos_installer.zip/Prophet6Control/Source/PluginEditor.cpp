#include "PluginEditor.h"

namespace
{
    class ParameterPage final : public juce::Component
    {
    public:
        ParameterPage(Prophet6ControlAudioProcessor& processor, const juce::String& section)
        {
            for (const auto& definition : p6::parameterDefinitions())
            {
                if (section != definition.section)
                    continue;

                auto label = std::make_unique<juce::Label>();
                label->setText(definition.name, juce::dontSendNotification);
                label->setJustificationType(juce::Justification::centred);
                label->setColour(juce::Label::textColourId, juce::Colour(0xffe9e1d0));
                label->setFont(juce::Font(11.5f));

                if (definition.toggle)
                {
                    auto button = std::make_unique<juce::ToggleButton>(definition.name);
                    button->setColour(juce::ToggleButton::textColourId, juce::Colour(0xffe9e1d0));
                    button->setColour(juce::ToggleButton::tickColourId, juce::Colour(0xffcf4d36));
                    button->setTooltip(juce::String("NRPN ") + juce::String(definition.nrpn));
                    buttonAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
                        processor.state, definition.id, *button));
                    labels.push_back(nullptr);
                    controls.push_back(std::move(button));
                }
                else if (definition.maximum - definition.minimum <= 9)
                {
                    auto combo = std::make_unique<juce::ComboBox>();
                    for (int value = definition.minimum; value <= definition.maximum; ++value)
                        combo->addItem(juce::String(value), value - definition.minimum + 1);
                    combo->setTooltip(juce::String("NRPN ") + juce::String(definition.nrpn));
                    combo->setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff292e35));
                    combo->setColour(juce::ComboBox::textColourId, juce::Colour(0xffe9e1d0));
                    combo->setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff555b63));
                    comboAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
                        processor.state, definition.id, *combo));
                    addAndMakeVisible(*label);
                    labels.push_back(std::move(label));
                    controls.push_back(std::move(combo));
                }
                else
                {
                    auto slider = std::make_unique<juce::Slider>();
                    slider->setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
                    slider->setTextBoxStyle(juce::Slider::TextBoxBelow, false, 62, 18);
                    slider->setRange(definition.minimum, definition.maximum, 1.0);
                    slider->setName(definition.name);
                    slider->setTooltip(juce::String("NRPN ") + juce::String(definition.nrpn));
                    slider->setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xffcf4d36));
                    slider->setColour(juce::Slider::rotarySliderOutlineColourId, juce::Colour(0xff41464d));
                    slider->setColour(juce::Slider::thumbColourId, juce::Colour(0xffe9e1d0));
                    sliderAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
                        processor.state, definition.id, *slider));
                    addAndMakeVisible(*label);
                    labels.push_back(std::move(label));
                    controls.push_back(std::move(slider));
                }
                addAndMakeVisible(*controls.back());
            }
        }

        void paint(juce::Graphics& g) override
        {
            g.fillAll(juce::Colour(0xff171a1f));
        }

        void resized() override
        {
            auto area = getLocalBounds().reduced(12);
            constexpr int columns = 4;
            constexpr int cellHeight = 128;
            const int cellWidth = juce::jmax(110, area.getWidth() / columns);
            for (std::size_t i = 0; i < controls.size(); ++i)
            {
                const int col = static_cast<int>(i % columns);
                const int row = static_cast<int>(i / columns);
                const int x = area.getX() + col * cellWidth;
                const int y = area.getY() + row * cellHeight;
                if (labels[i] != nullptr)
                {
                    labels[i]->setBounds(x, y, cellWidth, 22);
                    controls[i]->setBounds(x + 6, y + 24, cellWidth - 12, 96);
                }
                else
                {
                    controls[i]->setBounds(x + 8, y + 20, cellWidth - 16, 76);
                }
            }
        }

    private:
        std::vector<std::unique_ptr<juce::Label>> labels;
        std::vector<std::unique_ptr<juce::Component>> controls;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAttachments;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAttachments;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAttachments;
    };
}

Prophet6ControlAudioProcessorEditor::Prophet6ControlAudioProcessorEditor(Prophet6ControlAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    setSize(1280, 790);

    const juce::StringArray sections {
        "Oscillator 1", "Oscillator 2", "Mixer", "Low-pass Filter",
        "High-pass Filter", "Amplifier Envelope", "Filter Envelope", "LFO",
        "LFO Destinations", "Aftertouch", "Aftertouch Destinations", "Poly Mod",
        "Poly Mod Destinations", "Effects", "Effects 1", "Effects 2",
        "Glide / Unison", "Misc", "Arpeggiator", "Clock", "Tuning", "MIDI & Clock", "System"
    };

    for (const auto& section : sections)
    {
        auto page = std::make_unique<ParameterPage>(processor, section);
        tabs.addTab(section, juce::Colour(0xff292e35), page.get(), false);
        pages.push_back(std::move(page));
    }

    for (auto* button : { &loadButton, &saveButton, &requestDumpButton, &exportDumpButton, &sendAllButton, &sendGlobalsButton,
                          &recallHardwareButton, &dismissRecallButton })
    {
        button->setColour(juce::TextButton::buttonColourId, juce::Colour(0xff343b43));
        button->setColour(juce::TextButton::textColourOffId, juce::Colour(0xffe9e1d0));
        addAndMakeVisible(button);
    }

    recallPromptLabel.setText("Project or preset loaded. Send it to the Prophet 6?", juce::dontSendNotification);
    recallPromptLabel.setColour(juce::Label::textColourId, juce::Colour(0xffffd28a));
    recallPromptLabel.setFont(juce::Font(12.0f, juce::Font::bold));
    addAndMakeVisible(recallPromptLabel);
    recallPromptLabel.setVisible(processor.isHardwareRecallPending());
    recallHardwareButton.setVisible(processor.isHardwareRecallPending());
    dismissRecallButton.setVisible(processor.isHardwareRecallPending());
    recallHardwareButton.onClick = [this] { processor.confirmHardwareRecall(); resized(); };
    dismissRecallButton.onClick = [this] { processor.dismissHardwareRecall(); resized(); };

    loadButton.onClick = [this] { openPresetFile(); };
    saveButton.onClick = [this] { savePresetFile(); };
    requestDumpButton.onClick = [this] { processor.requestCurrentEditBufferDump(); };
    exportDumpButton.onClick = [this] { saveSysExFile(); };
    sendAllButton.onClick = [this] { processor.sendAllProgramParameters(); };
    sendGlobalsButton.onClick = [this] { processor.sendAllGlobalParameters(); };

    channelLabel.setText("MIDI OUT", juce::dontSendNotification);
    channelLabel.setColour(juce::Label::textColourId, juce::Colour(0xffb8b5ad));
    channelLabel.setJustificationType(juce::Justification::centredRight);
    addAndMakeVisible(channelLabel);
    for (int channel = 1; channel <= 16; ++channel)
        channelBox.addItem(juce::String(channel), channel);
    channelBox.setSelectedId(processor.getMidiChannel(), juce::dontSendNotification);
    channelBox.onChange = [this] { processor.setMidiChannel(channelBox.getSelectedId()); };
    addAndMakeVisible(channelBox);

    statusLabel.setColour(juce::Label::textColourId, juce::Colour(0xffb8b5ad));
    statusLabel.setFont(juce::Font(11.0f));
    statusLabel.setText(processor.getStatusText(), juce::dontSendNotification);
    addAndMakeVisible(statusLabel);
    addAndMakeVisible(tabs);
    startTimerHz(4);
}

void Prophet6ControlAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff101317));
    g.setColour(juce::Colour(0xffe9e1d0));
    g.setFont(juce::Font(21.0f, juce::Font::bold));
    g.drawText("SEQUENTIAL  /  PROPHET 6 CONTROL", 16, 10, getWidth() - 32, 28,
               juce::Justification::centredLeft);
}

void Prophet6ControlAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced(12);
    area.removeFromTop(34);
    auto controls = area.removeFromTop(32);
    loadButton.setBounds(controls.removeFromLeft(112));
    controls.removeFromLeft(6);
    saveButton.setBounds(controls.removeFromLeft(108));
    controls.removeFromLeft(6);
    requestDumpButton.setBounds(controls.removeFromLeft(174));
    controls.removeFromLeft(6);
    exportDumpButton.setBounds(controls.removeFromLeft(112));
    controls.removeFromLeft(6);
    sendAllButton.setBounds(controls.removeFromLeft(132));
    controls.removeFromLeft(6);
    sendGlobalsButton.setBounds(controls.removeFromLeft(104));
    controls.removeFromLeft(12);
    channelLabel.setBounds(controls.removeFromLeft(74));
    controls.removeFromLeft(4);
    channelBox.setBounds(controls.removeFromLeft(56));
    if (processor.isHardwareRecallPending())
    {
        auto prompt = area.removeFromTop(30);
        recallPromptLabel.setBounds(prompt.removeFromLeft(juce::jmax(300, prompt.getWidth() - 220)));
        recallHardwareButton.setBounds(prompt.removeFromLeft(132).reduced(2, 1));
        dismissRecallButton.setBounds(prompt.removeFromLeft(92).reduced(2, 1));
    }
    statusLabel.setBounds(area.removeFromBottom(22));
    tabs.setBounds(area);
}

void Prophet6ControlAudioProcessorEditor::timerCallback()
{
    statusLabel.setText(processor.getStatusText(), juce::dontSendNotification);
    const bool recallPending = processor.isHardwareRecallPending();
    if (recallPromptLabel.isVisible() != recallPending)
    {
        recallPromptLabel.setVisible(recallPending);
        recallHardwareButton.setVisible(recallPending);
        dismissRecallButton.setVisible(recallPending);
        resized();
    }
    exportDumpButton.setEnabled(processor.hasCapturedSysEx());
    if (channelBox.getSelectedId() != processor.getMidiChannel())
        channelBox.setSelectedId(processor.getMidiChannel(), juce::dontSendNotification);
}

void Prophet6ControlAudioProcessorEditor::openPresetFile()
{
    fileChooser = std::make_unique<juce::FileChooser>(
        "Open Prophet-6 preset or SysEx", juce::File{}, "*.p6preset;*.syx");
    juce::Component::SafePointer<Prophet6ControlAudioProcessorEditor> safeThis(this);
    fileChooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [safeThis](const juce::FileChooser& chooser)
        {
            if (safeThis == nullptr)
                return;
            const auto file = chooser.getResult();
            if (file == juce::File{})
                return;
            if (file.hasFileExtension("syx"))
                safeThis->processor.importSysEx(file);
            else
                safeThis->processor.importPreset(file);
        });
}

void Prophet6ControlAudioProcessorEditor::savePresetFile()
{
    fileChooser = std::make_unique<juce::FileChooser>(
        "Save Prophet-6 Control preset", juce::File::getSpecialLocation(juce::File::userDocumentsDirectory)
            .getChildFile("New Prophet Patch.p6preset"), "*.p6preset");
    juce::Component::SafePointer<Prophet6ControlAudioProcessorEditor> safeThis(this);
    fileChooser->launchAsync(juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles,
        [safeThis](const juce::FileChooser& chooser)
        {
            if (safeThis == nullptr)
                return;
            const auto file = chooser.getResult();
            if (file != juce::File{})
                safeThis->processor.exportPreset(file, file.getFileNameWithoutExtension());
        });
}

void Prophet6ControlAudioProcessorEditor::saveSysExFile()
{
    fileChooser = std::make_unique<juce::FileChooser>(
        "Export captured Prophet-6 SysEx", juce::File::getSpecialLocation(juce::File::userDocumentsDirectory)
            .getChildFile("Prophet-6 Edit Buffer.syx"), "*.syx");
    juce::Component::SafePointer<Prophet6ControlAudioProcessorEditor> safeThis(this);
    fileChooser->launchAsync(juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles,
        [safeThis](const juce::FileChooser& chooser)
        {
            if (safeThis == nullptr)
                return;
            const auto file = chooser.getResult();
            if (file != juce::File{})
                safeThis->processor.exportCapturedSysEx(file.withFileExtension("syx"));
        });
}
