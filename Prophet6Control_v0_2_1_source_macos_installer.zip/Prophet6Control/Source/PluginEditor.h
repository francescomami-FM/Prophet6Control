#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

class Prophet6ControlAudioProcessorEditor : public juce::AudioProcessorEditor,
                                             private juce::Timer
{
public:
    explicit Prophet6ControlAudioProcessorEditor(Prophet6ControlAudioProcessor&);
    ~Prophet6ControlAudioProcessorEditor() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void openPresetFile();
    void savePresetFile();
    void saveSysExFile();

    Prophet6ControlAudioProcessor& processor;
    juce::TabbedComponent tabs { juce::TabbedButtonBar::TabsAtTop };
    std::vector<std::unique_ptr<juce::Component>> pages;

    juce::TextButton loadButton { "Load Preset" };
    juce::TextButton saveButton { "Save Preset" };
    juce::TextButton requestDumpButton { "Request Hardware Patch" };
    juce::TextButton exportDumpButton { "Export SysEx" };
    juce::TextButton sendAllButton { "Send Parameters" };
    juce::TextButton sendGlobalsButton { "Send Globals" };
    juce::Label recallPromptLabel;
    juce::TextButton recallHardwareButton { "Recall Hardware" };
    juce::TextButton dismissRecallButton { "Not Now" };
    juce::Label channelLabel;
    juce::ComboBox channelBox;
    juce::Label statusLabel;
    std::unique_ptr<juce::FileChooser> fileChooser;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(Prophet6ControlAudioProcessorEditor)
};
