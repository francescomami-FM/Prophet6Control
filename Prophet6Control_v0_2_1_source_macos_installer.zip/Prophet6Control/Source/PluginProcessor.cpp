#include "PluginProcessor.h"
#include "PluginEditor.h"

#include <algorithm>
#include <cstring>
#include <limits>

namespace
{
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout()
    {
        juce::AudioProcessorValueTreeState::ParameterLayout layout;
        for (const auto& definition : p6::parameterDefinitions())
        {
            layout.add(std::make_unique<juce::AudioParameterInt>(
                definition.id,
                definition.name,
                definition.minimum,
                definition.maximum,
                definition.defaultValue));
        }
        return layout;
    }

    juce::String base64FromBytes(const std::uint8_t* data, std::size_t size)
    {
        return juce::Base64::toBase64(data, static_cast<int>(size));
    }

    bool bytesFromBase64(const juce::String& encoded, std::vector<std::uint8_t>& result)
    {
        result.clear();
        juce::MemoryBlock decoded;
        if (encoded.isEmpty() || !juce::Base64::convertFromBase64(decoded, encoded))
            return false;
        const auto* begin = static_cast<const std::uint8_t*>(decoded.getData());
        result.assign(begin, begin + decoded.getSize());
        return !result.empty();
    }

    bool fileBytesToSingleP6Message(const juce::File& file, std::vector<std::uint8_t>& message)
    {
        juce::MemoryBlock data;
        if (!file.loadFileAsData(data) || data.getSize() < 5)
            return false;

        const auto* bytes = static_cast<const std::uint8_t*>(data.getData());
        const auto size = data.getSize();
        std::size_t start = 0;
        while (start < size && bytes[start] != 0xF0)
            ++start;
        if (start == size)
            return false;

        std::size_t end = start;
        while (end < size && bytes[end] != 0xF7)
            ++end;
        if (end == size)
            return false;

        message.assign(bytes + start, bytes + end + 1);
        return true;
    }
}

Prophet6ControlAudioProcessor::Prophet6ControlAudioProcessor()
    : AudioProcessor(BusesProperties()),
      state(*this, nullptr, "P6STATE", createParameterLayout())
{
    lastSentValues.assign(p6::parameterDefinitions().size(), std::numeric_limits<int>::min());
    recallIndices.reserve(p6::parameterDefinitions().size());
    recallValues.reserve(p6::parameterDefinitions().size());
    for (auto& value : activeSysExOverrideValues)
        value.store(-1);
    for (auto& value : hardwareParameterPending)
        value.store(-1);
}

void Prophet6ControlAudioProcessor::prepareToPlay(double, int)
{
    parameterCacheInitialised.store(false, std::memory_order_release);
}

void Prophet6ControlAudioProcessor::releaseResources() {}

bool Prophet6ControlAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    return layouts.getMainInputChannelSet().isDisabled()
        && layouts.getMainOutputChannelSet().isDisabled();
}

int Prophet6ControlAudioProcessor::getCurrentParameterValue(std::size_t index) const
{
    const auto& definitions = p6::parameterDefinitions();
    if (index >= definitions.size())
        return 0;
    if (const auto* value = state.getRawParameterValue(definitions[index].id))
        return juce::roundToInt(value->load());
    return definitions[index].defaultValue;
}

void Prophet6ControlAudioProcessor::initialiseParameterCache()
{
    for (std::size_t i = 0; i < lastSentValues.size(); ++i)
        lastSentValues[i] = getCurrentParameterValue(i);
    parameterCacheInitialised.store(true, std::memory_order_release);
}

void Prophet6ControlAudioProcessor::emitNrpn(juce::MidiBuffer& output, int sample, int nrpn, int value)
{
    const auto encoded = p6::encodeNrpn(nrpn, value);
    const int channel = outputMidiChannel.load();

    // Always send the complete NRPN address and value. The Prophet retains its
    // selected NRPN, but a full message remains correct if another MIDI source
    // interleaves messages on the same output port.
    output.addEvent(juce::MidiMessage::controllerEvent(channel, encoded[0].controller, encoded[0].value), sample);
    output.addEvent(juce::MidiMessage::controllerEvent(channel, encoded[1].controller, encoded[1].value), sample);
    output.addEvent(juce::MidiMessage::controllerEvent(channel, encoded[2].controller, encoded[2].value), sample);
    output.addEvent(juce::MidiMessage::controllerEvent(channel, encoded[3].controller, encoded[3].value), sample);
}

bool Prophet6ControlAudioProcessor::shouldRecallParameter(const p6::ParameterDefinition& definition,
                                                           bool includeGlobals) const
{
    if (definition.readOnly)
        return false;
    // Program and global recalls are intentionally mutually exclusive.
    // Send Globals must never overwrite the current sound patch.
    return includeGlobals
        ? definition.domain == p6::ParameterDomain::Global
        : definition.domain == p6::ParameterDomain::Program;
}

void Prophet6ControlAudioProcessor::processRecallQueue(juce::MidiBuffer& midi)
{
    if (recallAllRequested.exchange(false))
    {
        recallIncludeGlobals = recallGlobalsRequested.exchange(false);
        recallIndices.clear();
        recallValues.clear();
        const auto& definitions = p6::parameterDefinitions();
        for (std::size_t i = 0; i < definitions.size(); ++i)
        {
            if (shouldRecallParameter(definitions[i], recallIncludeGlobals))
            {
                recallIndices.push_back(static_cast<int>(i));
                recallValues.push_back(getCurrentParameterValue(i));
            }
        }
        recallCursor = 0;
        recallActive = true;
    }

    int sentThisBlock = 0;
    const auto& definitions = p6::parameterDefinitions();
    while (recallActive && recallCursor < static_cast<int>(recallIndices.size())
           && sentThisBlock < kParametersPerRecallBlock)
    {
        const int index = recallIndices[static_cast<std::size_t>(recallCursor)];
        const int value = recallValues[static_cast<std::size_t>(recallCursor)];
        emitNrpn(midi, 0, definitions[static_cast<std::size_t>(index)].nrpn, value);
        if (definitions[static_cast<std::size_t>(index)].nrpn == 1026 && value >= 1 && value <= 16)
            outputMidiChannel.store(value, std::memory_order_release);
        lastSentValues[static_cast<std::size_t>(index)] = value;
        if (activeEditBufferSize.load(std::memory_order_acquire) > 0
            && definitions[static_cast<std::size_t>(index)].domain == p6::ParameterDomain::Program)
            activeSysExOverrideValues[static_cast<std::size_t>(index)].store(value, std::memory_order_release);
        ++recallCursor;
        ++sentThisBlock;
    }

    if (recallActive && recallCursor >= static_cast<int>(recallIndices.size()))
    {
        recallActive = false;
        updateStatus(recallIncludeGlobals
            ? "Writable global parameter recall sent. NRPN does not provide a hardware acknowledgement."
            : "Program parameter recall sent. NRPN does not provide a hardware acknowledgement.");
    }
}

void Prophet6ControlAudioProcessor::processParameterAutomation(juce::MidiBuffer& midi)
{
    const auto& definitions = p6::parameterDefinitions();
    const bool nativeEditBufferLoaded = activeEditBufferSize.load(std::memory_order_acquire) > 0;

    for (std::size_t i = 0; i < definitions.size(); ++i)
    {
        const auto& definition = definitions[i];
        if (definition.readOnly || definition.domain == p6::ParameterDomain::Global
            || std::strncmp(definition.id, "sequencer_", 10) == 0)
            continue;

        if (hardwareParameterPending[i].load(std::memory_order_acquire) >= 0)
            continue;

        const int value = getCurrentParameterValue(i);
        if (value == lastSentValues[i])
            continue;

        emitNrpn(midi, 0, definition.nrpn, value);
        lastSentValues[i] = value;

        if (nativeEditBufferLoaded)
            activeSysExOverrideValues[i].store(value, std::memory_order_release);
    }
}

void Prophet6ControlAudioProcessor::processGlobalParameterAutomation(juce::MidiBuffer& midi)
{
    const auto& definitions = p6::parameterDefinitions();
    for (std::size_t i = 0; i < definitions.size(); ++i)
    {
        const auto& definition = definitions[i];
        if (definition.domain != p6::ParameterDomain::Global || definition.readOnly)
            continue;

        if (hardwareParameterPending[i].load(std::memory_order_acquire) >= 0)
            continue;

        const int value = getCurrentParameterValue(i);
        if (value == lastSentValues[i])
            continue;

        emitNrpn(midi, 0, definition.nrpn, value);
        if (definition.nrpn == 1026 && value >= 1 && value <= 16)
            outputMidiChannel.store(value, std::memory_order_release);
        lastSentValues[i] = value;
    }
}

void Prophet6ControlAudioProcessor::publishActiveEditBuffer(const std::uint8_t* bytes, std::size_t size)
{
    if (bytes == nullptr || size == 0 || size > kMaxSysExBytes)
        return;

    activeEditBufferVersion.fetch_add(1, std::memory_order_acq_rel); // odd: write in progress
    for (std::size_t i = 0; i < size; ++i)
        activeEditBufferBytes[i].store(bytes[i], std::memory_order_relaxed);
    activeEditBufferSize.store(static_cast<int>(size), std::memory_order_relaxed);
    activeEditBufferVersion.fetch_add(1, std::memory_order_release); // even: stable snapshot
}

std::vector<std::uint8_t> Prophet6ControlAudioProcessor::readActiveEditBuffer() const
{
    std::vector<std::uint8_t> result;
    for (int attempt = 0; attempt < 4; ++attempt)
    {
        const auto versionBefore = activeEditBufferVersion.load(std::memory_order_acquire);
        if ((versionBefore & 1u) != 0u)
            continue;
        const int size = activeEditBufferSize.load(std::memory_order_relaxed);
        if (size <= 0 || static_cast<std::size_t>(size) > kMaxSysExBytes)
            return {};
        result.resize(static_cast<std::size_t>(size));
        for (int i = 0; i < size; ++i)
            result[static_cast<std::size_t>(i)] = activeEditBufferBytes[static_cast<std::size_t>(i)].load(std::memory_order_relaxed);
        const auto versionAfter = activeEditBufferVersion.load(std::memory_order_acquire);
        if (versionBefore == versionAfter)
            return result;
    }
    return {};
}

void Prophet6ControlAudioProcessor::stageHardwareRecallSysEx(const std::vector<std::uint8_t>& bytes)
{
    const juce::ScopedLock lock(stagedRecallLock);
    stagedHardwareRecallSysEx = bytes;
}

std::vector<std::uint8_t> Prophet6ControlAudioProcessor::readStagedHardwareRecallSysEx() const
{
    const juce::ScopedLock lock(stagedRecallLock);
    return stagedHardwareRecallSysEx;
}

void Prophet6ControlAudioProcessor::clearStagedHardwareRecallSysEx()
{
    const juce::ScopedLock lock(stagedRecallLock);
    stagedHardwareRecallSysEx.clear();
}

void Prophet6ControlAudioProcessor::captureSysEx(const juce::MidiMessage& message)
{
    const int size = message.getRawDataSize();
    if (size <= 0 || static_cast<std::size_t>(size) > kMaxSysExBytes)
        return;

    capturedSysExVersion.fetch_add(1, std::memory_order_acq_rel);
    for (int i = 0; i < size; ++i)
        capturedSysExBytes[static_cast<std::size_t>(i)].store(message.getRawData()[i], std::memory_order_relaxed);
    capturedSysExSize.store(size, std::memory_order_relaxed);
    capturedSysExVersion.fetch_add(1, std::memory_order_release);

    const auto* raw = message.getRawData();
    // Prophet-6 Program Edit Buffer Data Dump: F0 01 2D 03 + 1171 packed bytes + F7.
    if (size == 1176 && raw[0] == 0xF0 && raw[1] == 0x01 && raw[2] == 0x2D
        && raw[3] == 0x03 && raw[size - 1] == 0xF7)
    {
        publishActiveEditBuffer(raw, static_cast<std::size_t>(size));
        for (auto& value : activeSysExOverrideValues)
            value.store(-1, std::memory_order_release);
        updateStatus("Prophet-6 edit buffer captured. SysEx preserves the sound; panel values are not decoded from the dump yet.");
    }
    else
    {
        updateStatus("MIDI SysEx received.");
    }
}

std::vector<std::uint8_t> Prophet6ControlAudioProcessor::readCapturedSysEx() const
{
    std::vector<std::uint8_t> result;
    for (int attempt = 0; attempt < 4; ++attempt)
    {
        const auto versionBefore = capturedSysExVersion.load(std::memory_order_acquire);
        if ((versionBefore & 1u) != 0u)
            continue;
        const int size = capturedSysExSize.load(std::memory_order_relaxed);
        if (size <= 0 || static_cast<std::size_t>(size) > kMaxSysExBytes)
            return {};
        result.resize(static_cast<std::size_t>(size));
        for (int i = 0; i < size; ++i)
            result[static_cast<std::size_t>(i)] = capturedSysExBytes[static_cast<std::size_t>(i)].load(std::memory_order_relaxed);
        const auto versionAfter = capturedSysExVersion.load(std::memory_order_acquire);
        if (versionBefore == versionAfter)
            return result;
    }
    return {};
}

bool Prophet6ControlAudioProcessor::queueSysEx(const std::vector<std::uint8_t>& bytes)
{
    if (bytes.empty() || bytes.size() > kMaxSysExBytes)
    {
        updateStatus("SysEx message is empty or exceeds the supported size.");
        return false;
    }

    int expected = 0;
    if (!pendingSysExState.compare_exchange_strong(expected, 1, std::memory_order_acq_rel))
    {
        updateStatus("A SysEx transfer is already queued. Wait for it to finish before queuing another.");
        return false;
    }
    for (std::size_t i = 0; i < bytes.size(); ++i)
        pendingSysExBytes[i].store(bytes[i], std::memory_order_relaxed);
    pendingSysExSize.store(static_cast<int>(bytes.size()), std::memory_order_relaxed);
    pendingSysExState.store(2, std::memory_order_release);
    return true;
}

void Prophet6ControlAudioProcessor::setParameterFromHardware(int nrpn, int value)
{
    const auto* definition = p6::findParameterByNrpn(nrpn);
    if (definition == nullptr)
        return;

    const int index = p6::parameterIndex(definition->id);
    if (index < 0)
        return;

    const int bounded = p6::clampParameterValue(*definition, value);
    if (nrpn == 1026 && bounded >= 1 && bounded <= 16)
        outputMidiChannel.store(bounded, std::memory_order_release);
    const auto parameterIndex = static_cast<std::size_t>(index);
    hardwareParameterPending[parameterIndex].store(bounded, std::memory_order_release);
    lastSentValues[parameterIndex] = bounded;
    if (activeEditBufferSize.load(std::memory_order_acquire) > 0)
        activeSysExOverrideValues[parameterIndex].store(bounded, std::memory_order_release);
    triggerAsyncUpdate();
}

void Prophet6ControlAudioProcessor::setParameterFromHardwareCC(int cc, int value)
{
    const auto* definition = p6::findParameterByCC(cc);
    if (definition == nullptr)
        return;
    setParameterFromHardware(definition->nrpn, p6::ccToParameterValue(*definition, value));
}

void Prophet6ControlAudioProcessor::decodeIncoming(const juce::MidiMessage& message)
{
    if (message.isSysEx())
    {
        captureSysEx(message);
        return;
    }
    if (!message.isController())
        return;

    p6::NrpnDecoder::DecodedValue decoded;
    const int channelZeroBased = message.getChannel() - 1;
    const int cc = message.getControllerNumber();
    const int value = message.getControllerValue();

    if (nrpnDecoder.processCC(channelZeroBased, cc, value, decoded))
    {
        setParameterFromHardware(decoded.nrpn, decoded.value);
        return;
    }

    // Direct CC fallback is limited to Sequential's published CC table.
    if (cc != 99 && cc != 98 && cc != 6 && cc != 38 && cc != 96 && cc != 97)
        setParameterFromHardwareCC(cc, value);
}

void Prophet6ControlAudioProcessor::processBlock(juce::AudioBuffer<float>& audio, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    audio.clear();

    if (!parameterCacheInitialised.load(std::memory_order_acquire))
        initialiseParameterCache();

    // Incoming NRPN/CC events remain in the MIDI buffer so Logic can record
    // the original controller data and replay it through this MIDI processor.
    for (const auto metadata : midi)
        decodeIncoming(metadata.getMessage());

    int readyState = 2;
    if (pendingSysExState.compare_exchange_strong(readyState, 3, std::memory_order_acq_rel))
    {
        const int size = pendingSysExSize.load(std::memory_order_relaxed);
        std::array<std::uint8_t, kMaxSysExBytes> localSysEx {};
        if (size > 0 && static_cast<std::size_t>(size) <= kMaxSysExBytes)
        {
            for (int i = 0; i < size; ++i)
                localSysEx[static_cast<std::size_t>(i)] = pendingSysExBytes[static_cast<std::size_t>(i)].load(std::memory_order_relaxed);
            midi.addEvent(localSysEx.data(), size, 0);
            const bool isEditBufferDump = size == 1176 && localSysEx[0] == 0xF0
                && localSysEx[1] == 0x01 && localSysEx[2] == 0x2D
                && localSysEx[3] == 0x03 && localSysEx[1175] == 0xF7;
            if (isEditBufferDump)
            {
                publishActiveEditBuffer(localSysEx.data(), static_cast<std::size_t>(size));
                overrideRecallCursor = 0;
                delayOverridesOneBlock = true;
            }
        }
        pendingSysExState.store(0, std::memory_order_release);
    }

    bool deferOverrides = false;
    if (delayOverridesOneBlock)
    {
        delayOverridesOneBlock = false;
        deferOverrides = true;
    }

    if (!deferOverrides && activeEditBufferSize.load(std::memory_order_acquire) > 0
        && overrideRecallCursor >= 0)
    {
        const auto& definitions = p6::parameterDefinitions();
        int sent = 0;
        while (overrideRecallCursor < static_cast<int>(definitions.size())
               && sent < kParametersPerRecallBlock)
        {
            const auto index = static_cast<std::size_t>(overrideRecallCursor++);
            const int value = activeSysExOverrideValues[index].load(std::memory_order_acquire);
            const auto& definition = definitions[index];
            if (value < 0 || definition.domain == p6::ParameterDomain::Global
                || definition.readOnly || std::strncmp(definition.id, "sequencer_", 10) == 0)
                continue;

            emitNrpn(midi, 0, definition.nrpn, value);
            lastSentValues[index] = value;
            ++sent;
        }
        if (overrideRecallCursor >= static_cast<int>(definitions.size()))
            overrideRecallCursor = -1;
    }

    processRecallQueue(midi);
    processParameterAutomation(midi);
    processGlobalParameterAutomation(midi);
}

void Prophet6ControlAudioProcessor::sendAllProgramParameters()
{
    hardwareRecallConfirmationPending.store(false, std::memory_order_release);
    recallGlobalsRequested.store(false);
    recallAllRequested.store(true);
    updateStatus("Program parameter recall queued.");
}

void Prophet6ControlAudioProcessor::sendAllGlobalParameters()
{
    recallGlobalsRequested.store(true);
    recallAllRequested.store(true);
    updateStatus("Writable global parameter recall queued. Read-only MIDI Receive setting is excluded.");
}

void Prophet6ControlAudioProcessor::confirmHardwareRecall()
{
    if (!hardwareRecallConfirmationPending.exchange(false, std::memory_order_acq_rel))
        return;

    auto nativeDump = readActiveEditBuffer();
    if (nativeDump.empty())
        nativeDump = readStagedHardwareRecallSysEx();
    if (!nativeDump.empty())
    {
        if (!queueSysEx(nativeDump))
        {
            hardwareRecallConfirmationPending.store(true, std::memory_order_release);
            return;
        }
        updateStatus("Hardware recall confirmed. Native edit buffer queued before its NRPN overrides.");
    }
    else
    {
        sendAllProgramParameters();
        updateStatus("Hardware recall confirmed. Program parameter recall queued.");
    }
}

void Prophet6ControlAudioProcessor::dismissHardwareRecall()
{
    if (hardwareRecallConfirmationPending.exchange(false, std::memory_order_acq_rel))
        updateStatus("Hardware recall skipped. The loaded patch remains in the plug in without being sent.");
}

void Prophet6ControlAudioProcessor::requestCurrentEditBufferDump()
{
    if (queueSysEx(p6::makeEditBufferDumpRequest()))
        updateStatus("Edit-buffer request queued. Logic must route Prophet-6 USB MIDI input back to this track.");
}

bool Prophet6ControlAudioProcessor::exportCapturedSysEx(const juce::File& file) const
{
    const auto bytes = readCapturedSysEx();
    if (bytes.empty())
        return false;
    return file.replaceWithData(bytes.data(), bytes.size());
}

bool Prophet6ControlAudioProcessor::importSysEx(const juce::File& file)
{
    std::vector<std::uint8_t> bytes;
    if (!fileBytesToSingleP6Message(file, bytes))
    {
        updateStatus("No Prophet-6 SysEx message found in the selected file.");
        return false;
    }

    p6::Prophet6SysEx parsed;
    if (!p6::parseProphet6SysEx(bytes, parsed))
    {
        updateStatus("Unsupported SysEx. Import one Prophet-6 program or edit-buffer dump.");
        return false;
    }

    std::vector<std::uint8_t> editBuffer;
    if (parsed.kind == p6::SysExKind::EditBufferDump)
        editBuffer = bytes;
    else if (parsed.kind == p6::SysExKind::ProgramDump)
        editBuffer = p6::programDumpToEditBuffer(parsed);
    else
    {
        updateStatus("Global SysEx dumps are read-only. Restore Globals through individual NRPN settings.");
        return false;
    }

    for (auto& value : activeSysExOverrideValues)
        value.store(-1, std::memory_order_release);
    activeEditBufferSize.store(0, std::memory_order_release);
    stageHardwareRecallSysEx(editBuffer);
    hardwareRecallConfirmationPending.store(true, std::memory_order_release);
    updateStatus("Native patch imported locally. Confirm Recall Hardware to send it to the Prophet 6.");
    return true;
}

bool Prophet6ControlAudioProcessor::exportPreset(const juce::File& file, const juce::String& name)
{
    auto root = std::make_unique<juce::DynamicObject>();
    root->setProperty("format", "Prophet6ControlPreset");
    root->setProperty("schemaVersion", 1);
    root->setProperty("name", name.isNotEmpty() ? name : file.getFileNameWithoutExtension());

    auto parameters = std::make_unique<juce::DynamicObject>();
    for (std::size_t i = 0; i < p6::parameterDefinitions().size(); ++i)
        parameters->setProperty(p6::parameterDefinitions()[i].id, getCurrentParameterValue(i));
    root->setProperty("parameters", juce::var(parameters.release()));

    auto overrides = std::make_unique<juce::DynamicObject>();
    for (std::size_t i = 0; i < p6::parameterDefinitions().size(); ++i)
    {
        const int value = activeSysExOverrideValues[i].load(std::memory_order_acquire);
        if (value >= 0)
            overrides->setProperty(p6::parameterDefinitions()[i].id, value);
    }
    root->setProperty("nativeEditBufferOverrides", juce::var(overrides.release()));

    auto nativeDump = readActiveEditBuffer();
    if (nativeDump.empty())
        nativeDump = readStagedHardwareRecallSysEx();
    if (!nativeDump.empty())
        root->setProperty("nativeEditBufferSysEx", base64FromBytes(nativeDump.data(), nativeDump.size()));

    const auto json = juce::JSON::toString(juce::var(root.release()), true);
    const bool ok = file.withFileExtension("p6preset").replaceWithText(json);
    updateStatus(ok ? "Preset saved." : "Preset could not be saved.");
    return ok;
}

bool Prophet6ControlAudioProcessor::importPreset(const juce::File& file)
{
    const auto parsedJson = juce::JSON::parse(file.loadFileAsString());
    if (!parsedJson.isObject())
    {
        updateStatus("Invalid Prophet-6 Control preset file.");
        return false;
    }

    auto* object = parsedJson.getDynamicObject();
    if (object == nullptr || object->getProperty("format").toString() != "Prophet6ControlPreset"
        || static_cast<int>(object->getProperty("schemaVersion")) != 1)
    {
        updateStatus("Unsupported preset format or version.");
        return false;
    }

    auto* values = object->getProperty("parameters").getDynamicObject();
    if (values == nullptr)
    {
        updateStatus("Preset contains no parameter snapshot.");
        return false;
    }

    for (const auto& definition : p6::parameterDefinitions())
    {
        const juce::Identifier id(definition.id);
        if (!values->hasProperty(id))
            continue;
        const int value = p6::clampParameterValue(definition, static_cast<int>(values->getProperty(id)));
        if (auto* parameter = state.getParameter(definition.id))
            parameter->setValueNotifyingHost(parameter->convertTo0to1(static_cast<float>(value)));
    }

    for (auto& value : activeSysExOverrideValues)
        value.store(-1, std::memory_order_release);

    if (auto* overrides = object->getProperty("nativeEditBufferOverrides").getDynamicObject())
    {
        for (std::size_t i = 0; i < p6::parameterDefinitions().size(); ++i)
        {
            const auto& definition = p6::parameterDefinitions()[i];
            const juce::Identifier id(definition.id);
            if (overrides->hasProperty(id))
                activeSysExOverrideValues[i].store(p6::clampParameterValue(
                    definition, static_cast<int>(overrides->getProperty(id))), std::memory_order_release);
        }
    }

    std::vector<std::uint8_t> nativeBytes;
    const bool hasNativeDump = bytesFromBase64(object->getProperty("nativeEditBufferSysEx").toString(), nativeBytes);
    if (hasNativeDump)
    {
        p6::Prophet6SysEx nativeParsed;
        if (!p6::parseProphet6SysEx(nativeBytes, nativeParsed)
            || nativeParsed.kind != p6::SysExKind::EditBufferDump)
        {
            updateStatus("Preset contains an invalid native edit-buffer dump.");
            return false;
        }
        activeEditBufferSize.store(0, std::memory_order_release);
        stageHardwareRecallSysEx(nativeBytes);
        updateStatus("Preset loaded locally. Confirm Recall Hardware to send the native patch and its NRPN overrides.");
    }
    else
    {
        activeEditBufferSize.store(0, std::memory_order_release);
        clearStagedHardwareRecallSysEx();
        updateStatus("Preset loaded locally. Confirm Recall Hardware to send its program parameters.");
    }
    parameterCacheInitialised.store(false, std::memory_order_release);
    hardwareRecallConfirmationPending.store(true, std::memory_order_release);
    return true;
}

void Prophet6ControlAudioProcessor::getStateInformation(juce::MemoryBlock& destination)
{
    auto tree = state.copyState();
    auto nativeDump = readActiveEditBuffer();
    if (nativeDump.empty())
        nativeDump = readStagedHardwareRecallSysEx();
    if (!nativeDump.empty())
        tree.setProperty("nativeEditBufferSysEx", base64FromBytes(nativeDump.data(), nativeDump.size()), nullptr);
    else
        tree.removeProperty("nativeEditBufferSysEx", nullptr);

    tree.removeChild(tree.getChildWithName("P6Overrides"), nullptr);
    juce::ValueTree overrides("P6Overrides");
    for (std::size_t i = 0; i < p6::parameterDefinitions().size(); ++i)
    {
        const int value = activeSysExOverrideValues[i].load(std::memory_order_acquire);
        if (value >= 0)
            overrides.setProperty(p6::parameterDefinitions()[i].id, value, nullptr);
    }
    tree.addChild(overrides, -1, nullptr);

    if (auto xml = tree.createXml())
        copyXmlToBinary(*xml, destination);
}

void Prophet6ControlAudioProcessor::setStateInformation(const void* data, int size)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, size));
    if (xml == nullptr || !xml->hasTagName(state.state.getType()))
        return;

    auto restored = juce::ValueTree::fromXml(*xml);
    const auto encodedSysEx = restored.getProperty("nativeEditBufferSysEx").toString();
    std::vector<std::uint8_t> nativeBytes;
    const bool hasNativeDump = bytesFromBase64(encodedSysEx, nativeBytes);

    for (auto& value : activeSysExOverrideValues)
        value.store(-1, std::memory_order_release);
    const auto overrides = restored.getChildWithName("P6Overrides");
    if (overrides.isValid())
    {
        for (std::size_t i = 0; i < p6::parameterDefinitions().size(); ++i)
        {
            const auto& definition = p6::parameterDefinitions()[i];
            const juce::Identifier id(definition.id);
            if (overrides.hasProperty(id))
                activeSysExOverrideValues[i].store(p6::clampParameterValue(
                    definition, static_cast<int>(overrides.getProperty(id))), std::memory_order_release);
        }
    }

    state.replaceState(restored);
    parameterCacheInitialised.store(false, std::memory_order_release);

    if (hasNativeDump)
    {
        p6::Prophet6SysEx parsed;
        if (p6::parseProphet6SysEx(nativeBytes, parsed) && parsed.kind == p6::SysExKind::EditBufferDump)
        {
            activeEditBufferSize.store(0, std::memory_order_release);
            stageHardwareRecallSysEx(nativeBytes);
            updateStatus("Logic project state loaded. Confirm Recall Hardware to restore the Prophet-6 patch.");
        }
        else
        {
            activeEditBufferSize.store(0, std::memory_order_release);
            clearStagedHardwareRecallSysEx();
            updateStatus("Logic project parameters loaded. Confirm Recall Hardware to send them to the Prophet 6.");
        }
    }
    else
    {
        activeEditBufferSize.store(0, std::memory_order_release);
        clearStagedHardwareRecallSysEx();
        updateStatus("Logic project parameters loaded. Confirm Recall Hardware to send them to the Prophet 6.");
    }

    hardwareRecallConfirmationPending.store(true, std::memory_order_release);
}

void Prophet6ControlAudioProcessor::handleAsyncUpdate()
{
    const auto& definitions = p6::parameterDefinitions();
    for (std::size_t i = 0; i < definitions.size() && i < hardwareParameterPending.size(); ++i)
    {
        const int pendingValue = hardwareParameterPending[i].load(std::memory_order_acquire);
        if (pendingValue < 0)
            continue;
        const auto& definition = definitions[i];
        if (auto* parameter = state.getParameter(definition.id))
            parameter->setValueNotifyingHost(parameter->convertTo0to1(static_cast<float>(pendingValue)));
        int expected = pendingValue;
        if (!hardwareParameterPending[i].compare_exchange_strong(expected, -1,
                std::memory_order_acq_rel, std::memory_order_acquire))
            triggerAsyncUpdate();
    }
}

void Prophet6ControlAudioProcessor::updateStatus(const juce::String& text)
{
    const juce::ScopedLock lock(statusLock);
    statusText = text;
}

juce::String Prophet6ControlAudioProcessor::getStatusText() const
{
    const juce::ScopedLock lock(statusLock);
    return statusText;
}

bool Prophet6ControlAudioProcessor::hasCapturedSysEx() const
{
    return capturedSysExSize.load(std::memory_order_acquire) > 0;
}

juce::AudioProcessorEditor* Prophet6ControlAudioProcessor::createEditor()
{
    return new Prophet6ControlAudioProcessorEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new Prophet6ControlAudioProcessor();
}
