#pragma once

#include <JuceHeader.h>
#include "ParameterMap.h"
#include "ProtocolCore.h"

#include <array>
#include <atomic>
#include <cstdint>
#include <vector>

class Prophet6ControlAudioProcessor : public juce::AudioProcessor, private juce::AsyncUpdater
{
public:
    Prophet6ControlAudioProcessor();
    ~Prophet6ControlAudioProcessor() override = default;

    void prepareToPlay(double, int) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Prophet 6 Control"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return true; }
    bool isMidiEffect() const override { return true; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    bool exportPreset(const juce::File&, const juce::String& name);
    bool importPreset(const juce::File&);
    bool importSysEx(const juce::File&);
    bool exportCapturedSysEx(const juce::File&) const;
    void requestCurrentEditBufferDump();
    void sendAllProgramParameters();
    void sendAllGlobalParameters();
    bool isHardwareRecallPending() const { return hardwareRecallConfirmationPending.load(std::memory_order_acquire); }
    void confirmHardwareRecall();
    void dismissHardwareRecall();
    int getMidiChannel() const { return outputMidiChannel.load(); }
    void setMidiChannel(int channel) { outputMidiChannel.store(juce::jlimit(1, 16, channel)); }

    juce::String getStatusText() const;
    bool hasCapturedSysEx() const;

    juce::AudioProcessorValueTreeState state;

private:
    static constexpr std::size_t kMaxSysExBytes = 4096;
    static constexpr int kParametersPerRecallBlock = 2;

    void emitNrpn(juce::MidiBuffer&, int sample, int nrpn, int value);
    void decodeIncoming(const juce::MidiMessage&);
    void setParameterFromHardware(int nrpn, int value);
    void setParameterFromHardwareCC(int cc, int value);
    bool queueSysEx(const std::vector<std::uint8_t>&);
    void captureSysEx(const juce::MidiMessage&);
    std::vector<std::uint8_t> readCapturedSysEx() const;
    void publishActiveEditBuffer(const std::uint8_t* bytes, std::size_t size);
    std::vector<std::uint8_t> readActiveEditBuffer() const;
    void stageHardwareRecallSysEx(const std::vector<std::uint8_t>&);
    std::vector<std::uint8_t> readStagedHardwareRecallSysEx() const;
    void clearStagedHardwareRecallSysEx();
    void processRecallQueue(juce::MidiBuffer&);
    void processParameterAutomation(juce::MidiBuffer&);
    void processGlobalParameterAutomation(juce::MidiBuffer&);
    void initialiseParameterCache();
    int getCurrentParameterValue(std::size_t index) const;
    bool shouldRecallParameter(const p6::ParameterDefinition&, bool includeGlobals) const;
    void updateStatus(const juce::String& text);
    void handleAsyncUpdate() override;

    std::atomic<int> outputMidiChannel { 1 };
    p6::NrpnDecoder nrpnDecoder;
    std::vector<int> lastSentValues;
    std::atomic<bool> parameterCacheInitialised { false };

    std::atomic<bool> hardwareRecallConfirmationPending { false };
    std::atomic<bool> recallAllRequested { false };
    std::atomic<bool> recallGlobalsRequested { false };
    bool recallActive = false; // Audio thread only.
    bool recallIncludeGlobals = false; // Audio thread only.
    int recallCursor = 0; // Audio thread only.
    std::vector<int> recallIndices;
    std::vector<int> recallValues;

    // One producer (message thread), one consumer (audio thread).
    std::array<std::atomic<std::uint8_t>, kMaxSysExBytes> pendingSysExBytes {};
    std::atomic<int> pendingSysExSize { 0 };
    // 0 empty, 1 producer writing, 2 ready, 3 audio thread reading.
    std::atomic<int> pendingSysExState { 0 };

    // Sequence lock: audio thread publishes captured SysEx, UI thread reads it.
    std::array<std::atomic<std::uint8_t>, kMaxSysExBytes> capturedSysExBytes {};
    std::atomic<std::uint32_t> capturedSysExVersion { 0 };
    std::atomic<int> capturedSysExSize { 0 };

    // Latest edit-buffer dump used as the base sound for project recall.
    // The audio thread is the sole writer; UI/state code reads through a sequence lock.
    std::array<std::atomic<std::uint8_t>, kMaxSysExBytes> activeEditBufferBytes {};
    std::atomic<std::uint32_t> activeEditBufferVersion { 0 };
    std::atomic<int> activeEditBufferSize { 0 };
    std::array<std::atomic<int>, 128> activeSysExOverrideValues; // -1 means no override.
    std::array<std::atomic<int>, 128> hardwareParameterPending; // -1 means no queued hardware update.
    int overrideRecallCursor = -1; // Audio thread only.
    bool delayOverridesOneBlock = false; // Audio thread only.

    mutable juce::CriticalSection stagedRecallLock;
    std::vector<std::uint8_t> stagedHardwareRecallSysEx;

    mutable juce::CriticalSection statusLock;
    juce::String statusText { "No hardware response yet" };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(Prophet6ControlAudioProcessor)
};

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter();
