#pragma once

#include <array>
#include <cstdint>
#include <vector>

namespace p6
{
    struct ControlChange
    {
        int controller = 0;
        int value = 0;
    };

    // Prophet-6 NRPN is carried as ordinary MIDI CC messages.
    std::array<ControlChange, 4> encodeNrpn(int nrpn, int value);

    class NrpnDecoder
    {
    public:
        struct DecodedValue
        {
            int channel = 1; // MIDI channel, 1..16
            int nrpn = -1;
            int value = 0;
        };

        // Decodes full and abbreviated/running NRPN data entry messages.
        // Returns true when a complete parameter value is available.
        bool processCC(int channelZeroBased, int controller, int value, DecodedValue& decoded);
        void reset();

    private:
        struct ChannelState
        {
            int numberMsb = -1;
            int numberLsb = -1;
            int dataMsb = 0;
            int dataLsb = 0;
            bool hasDataMsb = false;
            bool hasDataLsb = false;
        };

        std::array<ChannelState, 16> states {};
    };

    enum class SysExKind
    {
        Unknown,
        ProgramDump,
        EditBufferDump,
        GlobalDump
    };

    struct Prophet6SysEx
    {
        SysExKind kind = SysExKind::Unknown;
        int bank = -1;
        int program = -1;
        std::vector<std::uint8_t> bytes;
        std::vector<std::uint8_t> packedProgramData;
    };

    // Prophet-6 program data is 1024 bytes packed into 1171 7-bit MIDI bytes.
    bool unpackProgramData(const std::vector<std::uint8_t>& packed,
                           std::vector<std::uint8_t>& unpacked);
    std::vector<std::uint8_t> packProgramData(const std::vector<std::uint8_t>& unpacked);

    bool parseProphet6SysEx(const std::vector<std::uint8_t>& bytes, Prophet6SysEx& parsed);
    std::vector<std::uint8_t> makeEditBufferDumpRequest();
    std::vector<std::uint8_t> makeProgramDumpRequest(int bank, int program);
    std::vector<std::uint8_t> programDumpToEditBuffer(const Prophet6SysEx& programDump);
}
