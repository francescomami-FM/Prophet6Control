# Protocol test report

Environment: development container, CMake native C++ build.

Command used:

```bash
cmake -S Tests -B build-tests
cmake --build build-tests --parallel
ctest --test-dir build-tests --output-on-failure
```

Result at the time this archive was prepared:

* 1 protocol test executable.
* 1 test registered with CTest.
* 1 test passed.
* 0 tests failed.

Coverage includes NRPN message composition, full and running NRPN decoding, channel isolation, parameter map identity and range checks, sequencer parameter exclusion, selected direct CC scaling, SysEx 7 bit pack and unpack, edit buffer request framing, and program dump to edit buffer framing.

This is a protocol unit test result only. It is not an AU or VST3 build result and does not validate the physical Prophet 6 or Logic routing.
