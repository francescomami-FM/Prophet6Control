# Protocol test cases to implement/run on bench

1. NRPN 45 Low Pass Frequency: send CC99=0, CC98=45, CC6=1, CC38=36. Verify parameter value 164 on device only after confirming scaling/range with the current firmware.
2. NRPN 78 Filter Envelope Attack: verify values 0, 64, 127 map to minimum, midpoint and maximum.
3. NRPN 121 FX1 Parameter 1: verify full 0–255 range using 14-bit data entry.
4. Receive hardware movement for NRPN 45 and confirm plug-in UI + host parameter follow without echo.
5. Rapidly automate NRPN 45 at 1/16-note intervals; verify no stuck or dropped updates.
6. Save project at one set of values, alter hardware, reopen project and verify recall stream.
7. Disconnect USB during recall. Verify plug-in retains state and reports failure/disconnection rather than claiming success.
8. Record physical cutoff changes into Logic MIDI region, stop, play region, verify Prophet follows.
9. Ensure recorded note data from Logic passes through untouched while parameter NRPN messages are also emitted.
