#include "ProtocolCore.h"
#include "ParameterMap.h"

#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>

int main()
{
    // The Prophet-6 encodes both the NRPN address and value as 7-bit pairs.
    {
        const auto encoded = p6::encodeNrpn(1027, 3);
        assert(encoded[0].controller == 99 && encoded[0].value == 8);
        assert(encoded[1].controller == 98 && encoded[1].value == 3);
        assert(encoded[2].controller == 6 && encoded[2].value == 0);
        assert(encoded[3].controller == 38 && encoded[3].value == 3);
    }

    // Full four-message NRPN and abbreviated running parameter updates.
    {
        p6::NrpnDecoder decoder;
        p6::NrpnDecoder::DecodedValue result;
        const auto encoded = p6::encodeNrpn(4, 255);
        assert(!decoder.processCC(0, encoded[0].controller, encoded[0].value, result));
        assert(!decoder.processCC(0, encoded[1].controller, encoded[1].value, result));
        assert(!decoder.processCC(0, encoded[2].controller, encoded[2].value, result));
        assert(decoder.processCC(0, encoded[3].controller, encoded[3].value, result));
        assert(result.channel == 1 && result.nrpn == 4 && result.value == 255);

        assert(!decoder.processCC(0, 6, 1, result));
        assert(decoder.processCC(0, 38, 2, result));
        assert(result.nrpn == 4 && result.value == 130);
    }

    // The decoder keeps the parameter selector isolated per MIDI channel.
    {
        p6::NrpnDecoder decoder;
        p6::NrpnDecoder::DecodedValue result;
        const auto ch10 = p6::encodeNrpn(1088, 1);
        for (const auto& cc : ch10)
            decoder.processCC(9, cc.controller, cc.value, result);
        assert(result.channel == 10 && result.nrpn == 1088 && result.value == 1);
    }

    // Parameter database integrity: stable IDs and NRPN addresses must be unique.
    // The internal Prophet step sequencer is deliberately not exposed.
    {
        const auto& definitions = p6::parameterDefinitions();
        assert(definitions.size() >= 70);
        for (std::size_t i = 0; i < definitions.size(); ++i)
        {
            assert(definitions[i].id != nullptr && definitions[i].id[0] != '\0');
            assert(definitions[i].minimum <= definitions[i].maximum);
            assert(definitions[i].defaultValue >= definitions[i].minimum);
            assert(definitions[i].defaultValue <= definitions[i].maximum);
            assert(definitions[i].nrpn >= 0 && definitions[i].nrpn <= 16383);
            assert(std::string(definitions[i].id).find("sequencer_") != 0);
            for (std::size_t j = i + 1; j < definitions.size(); ++j)
            {
                assert(std::string(definitions[i].id) != definitions[j].id);
                assert(definitions[i].nrpn != definitions[j].nrpn);
                if (definitions[i].directCC >= 0 && definitions[j].directCC >= 0)
                    assert(definitions[i].directCC != definitions[j].directCC);
            }
        }
    }

    // Confirm documented direct-CC parameter scaling.
    {
        const auto* cutoff = p6::findParameterByNrpn(45);
        assert(cutoff != nullptr);
        assert(cutoff->maximum == 164 && cutoff->directCC == 102);
        assert(p6::ccToParameterValue(*cutoff, 127) == 164);
        assert(p6::parameterValueToCC(*cutoff, 164) == 127);
        assert(p6::findParameterByNrpn(129) != nullptr);
        assert(p6::findParameterByNrpn(1041) != nullptr);
        assert(p6::findParameterByNrpn(1042) != nullptr);
    }

    // Packed 1024-byte patch data round-trips to 1171 legal 7-bit bytes.
    {
        std::vector<std::uint8_t> original(1024);
        for (std::size_t i = 0; i < original.size(); ++i)
            original[i] = static_cast<std::uint8_t>((i * 37 + 129) & 0xff);
        const auto packed = p6::packProgramData(original);
        assert(packed.size() == 1171);
        for (auto b : packed) assert(b <= 0x7f);
        std::vector<std::uint8_t> decoded;
        assert(p6::unpackProgramData(packed, decoded));
        assert(decoded == original);
    }

    // Edit buffer SysEx framing, request bytes and program-to-edit-buffer conversion.
    {
        const auto req = p6::makeEditBufferDumpRequest();
        assert((req == std::vector<std::uint8_t>{0xF0, 0x01, 0x2D, 0x06, 0xF7}));
        std::vector<std::uint8_t> raw(1024, 0xA5);
        const auto packed = p6::packProgramData(raw);
        std::vector<std::uint8_t> programDump{0xF0, 0x01, 0x2D, 0x02, 2, 17};
        programDump.insert(programDump.end(), packed.begin(), packed.end());
        programDump.push_back(0xF7);

        p6::Prophet6SysEx parsed;
        assert(p6::parseProphet6SysEx(programDump, parsed));
        assert(parsed.kind == p6::SysExKind::ProgramDump && parsed.bank == 2 && parsed.program == 17);
        const auto editBuffer = p6::programDumpToEditBuffer(parsed);
        assert(editBuffer.size() == 1176);
        assert(editBuffer[3] == 0x03 && editBuffer[4] == packed[0]);
        assert(editBuffer.back() == 0xF7);

        p6::Prophet6SysEx editParsed;
        assert(p6::parseProphet6SysEx(editBuffer, editParsed));
        assert(editParsed.kind == p6::SysExKind::EditBufferDump);
    }

    std::cout << "Prophet-6 protocol tests passed.\n";
    return 0;
}
