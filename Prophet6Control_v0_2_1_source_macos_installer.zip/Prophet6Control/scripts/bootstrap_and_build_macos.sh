#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JUCE_PATH="${JUCE_DIR:-$ROOT/third_party/JUCE}"
JUCE_TAG="${JUCE_TAG:-9.0.5}"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This script builds the macOS Audio Unit and DMG. Run it on macOS." >&2
  exit 10
fi

if [[ ! -f "$JUCE_PATH/CMakeLists.txt" ]]; then
  command -v git >/dev/null 2>&1 || { echo "git is required to obtain JUCE." >&2; exit 11; }
  mkdir -p "$(dirname "$JUCE_PATH")"
  git clone --depth 1 --branch "$JUCE_TAG" https://github.com/juce-framework/JUCE.git "$JUCE_PATH"
fi

"$ROOT/scripts/build_macos.sh" "$JUCE_PATH"
