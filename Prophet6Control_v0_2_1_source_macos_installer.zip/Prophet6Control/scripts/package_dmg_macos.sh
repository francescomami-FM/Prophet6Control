#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="${BUILD_DIR:-$ROOT/build}"
VERSION="${VERSION:-0.2.1}"
ARTIFACTS="$BUILD_DIR/Prophet6Control_artefacts/Release"
DIST="$ROOT/dist"
STAGE="$DIST/Prophet 6 Control Installer"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "A genuine macOS DMG must be created on macOS with hdiutil." >&2
  exit 10
fi
if ! command -v hdiutil >/dev/null 2>&1; then
  echo "hdiutil was not found. Install the macOS command line tools." >&2
  exit 11
fi
if [[ ! -d "$ARTIFACTS" ]]; then
  echo "Build artefacts were not found at: $ARTIFACTS" >&2
  echo "Run scripts/build_macos.sh first." >&2
  exit 12
fi

rm -rf "$STAGE"
mkdir -p "$STAGE/Audio Units" "$STAGE/VST3" "$STAGE/Applications"

find_bundle() {
  local pattern="$1"
  find "$ARTIFACTS" -type d -name "$pattern" -print -quit
}

AU_BUNDLE="$(find_bundle '*.component')"
VST3_BUNDLE="$(find_bundle '*.vst3')"
APP_BUNDLE="$(find_bundle '*.app')"

if [[ -z "$AU_BUNDLE" ]]; then
  echo "Audio Unit component bundle was not produced." >&2
  exit 13
fi

ditto "$AU_BUNDLE" "$STAGE/Audio Units/$(basename "$AU_BUNDLE")"
if [[ -n "$VST3_BUNDLE" ]]; then
  ditto "$VST3_BUNDLE" "$STAGE/VST3/$(basename "$VST3_BUNDLE")"
fi
if [[ -n "$APP_BUNDLE" ]]; then
  ditto "$APP_BUNDLE" "$STAGE/Applications/$(basename "$APP_BUNDLE")"
fi

cat > "$STAGE/Install.command" <<'INSTALLER'
#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
COMPONENTS="$HOME/Library/Audio/Plug-Ins/Components"
VST3="$HOME/Library/Audio/Plug-Ins/VST3"
APPS="$HOME/Applications"
mkdir -p "$COMPONENTS" "$VST3" "$APPS"

copy_bundle() {
  local source="$1"
  local destination="$2"
  local name
  name="$(basename "$source")"
  rm -rf "$destination/$name"
  ditto "$source" "$destination/$name"
  echo "Installed: $destination/$name"
}

while IFS= read -r -d '' bundle; do copy_bundle "$bundle" "$COMPONENTS"; done \
  < <(find "$HERE/Audio Units" -maxdepth 1 -type d -name '*.component' -print0)
while IFS= read -r -d '' bundle; do copy_bundle "$bundle" "$VST3"; done \
  < <(find "$HERE/VST3" -maxdepth 1 -type d -name '*.vst3' -print0)
while IFS= read -r -d '' bundle; do copy_bundle "$bundle" "$APPS"; done \
  < <(find "$HERE/Applications" -maxdepth 1 -type d -name '*.app' -print0)

echo
echo "Installation files copied. Restart Logic Pro and run Plug-in Manager validation if required."
read -r -p "Press Return to close this window. " _
INSTALLER
chmod +x "$STAGE/Install.command"

cat > "$STAGE/README.txt" <<'README'
PROPHET 6 CONTROL

Installation
1. Double-click Install.command.
2. If macOS blocks the script, Control-click it in Finder and choose Open.
3. Restart Logic Pro.
4. Open Logic Pro Plug-in Manager and validate Prophet 6 Control if it is not listed.
5. Add Prophet 6 Control as a MIDI FX plug-in before the External Instrument or software instrument routing used for the Prophet 6.

The Audio Unit is installed in ~/Library/Audio/Plug-Ins/Components.
The VST3 is installed in ~/Library/Audio/Plug-Ins/VST3.
The standalone application, if included in this build, is installed in ~/Applications.

Preset recall asks before sending a loaded project or preset to the hardware. Choose Recall Hardware in the plug-in, or Not Now to leave the Prophet unchanged.

This development build is not notarised. macOS may display a security warning. No Apple Developer ID signature is included unless the build is separately signed by its distributor.

The plug-in has not been validated against a physical Prophet 6 until the user completes the hardware test procedure.
README

DMG="$DIST/Prophet-6-Control-v$VERSION.dmg"
mkdir -p "$DIST"
rm -f "$DMG"
hdiutil create -volname "Prophet 6 Control" -srcfolder "$STAGE" -ov -format UDZO "$DMG"
echo "Created: $DMG"
